# Lista tasków stricte kodowych – frontend / backend

## 1. Struktura aplikacji i routing

- [ ] Utworzyć routing dla części publicznej aplikacji
- [ ] Utworzyć routing dla panelu HR
- [ ] Utworzyć routing dla panelu administratora
- [ ] Utworzyć routing dla obsługi logowania
- [ ] Utworzyć routing dla obsługi zgłoszeń po tokenie
- [ ] Utworzyć routing dla pobierania załączników
- [ ] Utworzyć routing dla akcji zmiany statusów zgłoszeń
- [ ] Utworzyć routing dla wiadomości w zgłoszeniu

## 2. Część publiczna – zgłaszający

- [ ] Stworzyć stronę startową dla zgłaszającego
- [ ] Stworzyć widok instrukcji / informacji o zgłaszaniu mobbingu
- [ ] Stworzyć formularz tworzenia anonimowego zgłoszenia
- [ ] Dodać walidację formularza zgłoszenia po stronie backendu
- [ ] Dodać walidację formularza zgłoszenia po stronie frontendu
- [ ] Stworzyć obsługę zapisu zgłoszenia jako wersji roboczej
- [ ] Stworzyć obsługę wysłania zgłoszenia
- [ ] Stworzyć generowanie i wyświetlanie tokenu zgłoszenia
- [ ] Stworzyć widok potwierdzenia utworzenia zgłoszenia
- [ ] Stworzyć formularz powrotu do zgłoszenia po tokenie
- [ ] Stworzyć widok zgłoszenia dostępny po tokenie
- [ ] Stworzyć tryb read-only dla zgłoszenia zamkniętego
- [ ] Stworzyć obsługę usuwania wersji roboczej
- [ ] Dodać komunikaty błędów i sukcesu dla zgłaszającego

## 3. Załączniki

- [ ] Dodać obsługę wyboru plików w formularzu zgłoszenia
- [ ] Dodać backendową obsługę uploadu załączników
- [ ] Dodać walidację typu pliku
- [ ] Dodać walidację rozmiaru pliku
- [ ] Dodać listę załączników przy zgłoszeniu
- [ ] Dodać możliwość usunięcia załącznika z wersji roboczej
- [ ] Dodać bezpieczne pobieranie załączników przez HR
- [ ] Dodać bezpieczne pobieranie załączników przez zgłaszającego po tokenie
- [ ] Zabezpieczyć dostęp do załączników przed nieuprawnionym pobraniem

## 4. Komunikacja zgłaszający – HR

- [ ] Stworzyć widok wiadomości przy zgłoszeniu dla zgłaszającego
- [ ] Stworzyć formularz dodawania wiadomości przez zgłaszającego
- [ ] Stworzyć widok wiadomości przy zgłoszeniu dla HR
- [ ] Stworzyć formularz dodawania wiadomości przez HR
- [ ] Dodać rozróżnienie autora wiadomości
- [ ] Dodać sortowanie wiadomości chronologicznie
- [ ] Dodać blokadę dodawania wiadomości po zamknięciu zgłoszenia
- [ ] Dodać odświeżanie widoku wiadomości po zapisaniu odpowiedzi
- [ ] Dodać komunikaty o braku wiadomości

## 5. Panel HR

- [ ] Stworzyć dashboard HR
- [ ] Stworzyć listę zgłoszeń dla HR
- [ ] Dodać filtrowanie zgłoszeń po statusie
- [ ] Dodać wyszukiwanie zgłoszeń
- [ ] Dodać sortowanie zgłoszeń
- [ ] Stworzyć widok szczegółów zgłoszenia dla HR
- [ ] Dodać zmianę statusu zgłoszenia
- [ ] Dodać przypisywanie zgłoszenia do użytkownika HR
- [ ] Dodać obsługę notatek wewnętrznych HR
- [ ] Dodać widoczność załączników w szczegółach zgłoszenia
- [ ] Dodać widoczność historii wiadomości
- [ ] Dodać akcję zamknięcia zgłoszenia
- [ ] Dodać blokadę edycji zamkniętego zgłoszenia
- [ ] Dodać komunikaty akcji w panelu HR

## 6. Panel administratora

- [ ] Stworzyć dashboard administratora
- [ ] Stworzyć listę użytkowników
- [ ] Stworzyć formularz dodawania użytkownika
- [ ] Stworzyć formularz edycji użytkownika
- [ ] Dodać zmianę roli użytkownika
- [ ] Dodać aktywowanie i dezaktywowanie użytkowników
- [ ] Dodać resetowanie hasła użytkownika
- [ ] Dodać walidację formularzy użytkowników
- [ ] Dodać listę zgłoszeń dostępną dla administratora
- [ ] Dodać podgląd szczegółów zgłoszenia dla administratora
- [ ] Dodać widok audytu systemowego
- [ ] Dodać filtrowanie wpisów audytu
- [ ] Dodać komunikaty akcji administracyjnych

## 7. Logowanie i autoryzacja

- [ ] Stworzyć widok logowania użytkownika wewnętrznego
- [ ] Stworzyć backendową obsługę logowania
- [ ] Stworzyć backendową obsługę wylogowania
- [ ] Dodać middleware zabezpieczający panel HR
- [ ] Dodać middleware zabezpieczający panel administratora
- [ ] Dodać sprawdzanie ról użytkowników
- [ ] Dodać przekierowania po zalogowaniu zależnie od roli
- [ ] Dodać obsługę błędnych danych logowania
- [ ] Dodać ochronę przed dostępem do nieuprawnionych widoków
- [ ] Dodać zabezpieczenie akcji backendowych przed nieuprawnionym użyciem

## 8. Statusy i logika zgłoszeń

- [ ] Zaimplementować logikę tworzenia nowego zgłoszenia
- [ ] Zaimplementować logikę wersji roboczej
- [ ] Zaimplementować logikę wysłania zgłoszenia
- [ ] Zaimplementować logikę zmiany statusu zgłoszenia
- [ ] Zaimplementować logikę zamknięcia zgłoszenia
- [ ] Zaimplementować logikę blokady zamkniętego zgłoszenia
- [ ] Zaimplementować logikę dostępu do zgłoszenia po tokenie
- [ ] Zaimplementować logikę ukrywania danych technicznych przed zgłaszającym
- [ ] Zaimplementować logikę walidacji dozwolonych przejść między statusami

## 9. Audyt i logowanie zdarzeń

- [ ] Dodać zapisywanie zdarzenia utworzenia zgłoszenia
- [ ] Dodać zapisywanie zdarzenia wysłania zgłoszenia
- [ ] Dodać zapisywanie zdarzenia zmiany statusu
- [ ] Dodać zapisywanie zdarzenia dodania wiadomości
- [ ] Dodać zapisywanie zdarzenia dodania załącznika
- [ ] Dodać zapisywanie zdarzenia pobrania załącznika
- [ ] Dodać zapisywanie zdarzenia logowania użytkownika
- [ ] Dodać zapisywanie zdarzenia operacji administracyjnych
- [ ] Stworzyć helper / serwis do zapisywania audytu
- [ ] Stworzyć widok listy wpisów audytu
- [ ] Dodać filtrowanie audytu po typie zdarzenia
- [ ] Dodać filtrowanie audytu po użytkowniku
- [ ] Dodać filtrowanie audytu po zgłoszeniu

## 10. Retencja i automatyczne czyszczenie

- [ ] Zaimplementować logikę wykrywania starych wersji roboczych
- [ ] Zaimplementować usuwanie przeterminowanych wersji roboczych
- [ ] Zaimplementować czyszczenie powiązanych wiadomości roboczych
- [ ] Zaimplementować czyszczenie powiązanych załączników roboczych
- [ ] Dodać kod komendy aplikacyjnej do czyszczenia danych
- [ ] Dodać komunikaty / wynik wykonania komendy retencyjnej
- [ ] Dodać wpisy audytu dla operacji retencyjnych

## 11. Frontend wspólny

- [ ] Przygotować główny layout aplikacji
- [ ] Przygotować layout części publicznej
- [ ] Przygotować layout panelu HR
- [ ] Przygotować layout panelu administratora
- [ ] Przygotować komponent nagłówka
- [ ] Przygotować komponent menu
- [ ] Przygotować komponent stopki
- [ ] Przygotować komponent komunikatów flash
- [ ] Przygotować komponent kart / paneli
- [ ] Przygotować komponent tabel
- [ ] Przygotować komponent formularzy
- [ ] Przygotować komponent status badge
- [ ] Przygotować komponent pustego stanu listy
- [ ] Przygotować komponent potwierdzenia akcji

## 12. Responsywność i UX

- [ ] Dostosować stronę publiczną do urządzeń mobilnych
- [ ] Dostosować formularz zgłoszenia do małych ekranów
- [ ] Dostosować panel HR do mniejszych ekranów
- [ ] Dostosować panel administratora do mniejszych ekranów
- [ ] Dodać czytelne odstępy i skalowanie elementów
- [ ] Dodać responsywne tabele lub alternatywny widok kart
- [ ] Dodać stany hover / focus dla elementów interaktywnych
- [ ] Dodać widoczne komunikaty błędów formularzy
- [ ] Dodać potwierdzenia dla akcji destrukcyjnych
- [ ] Uporządkować kolejność pól formularzy

## 13. Walidacja i obsługa błędów

- [ ] Dodać walidację tworzenia zgłoszenia
- [ ] Dodać walidację edycji wersji roboczej
- [ ] Dodać walidację dodawania wiadomości
- [ ] Dodać walidację uploadu załączników
- [ ] Dodać walidację zmiany statusu
- [ ] Dodać walidację formularzy użytkowników
- [ ] Dodać obsługę błędnego tokenu
- [ ] Dodać obsługę wygasłego / usuniętego zgłoszenia roboczego
- [ ] Dodać obsługę braku uprawnień
- [ ] Dodać obsługę nieistniejącego zasobu
- [ ] Dodać przyjazne strony błędów

## 14. Kontrolery backendowe

- [ ] Napisać kontroler strony publicznej
- [ ] Napisać kontroler zgłoszeń publicznych
- [ ] Napisać kontroler dostępu po tokenie
- [ ] Napisać kontroler załączników
- [ ] Napisać kontroler wiadomości
- [ ] Napisać kontroler panelu HR
- [ ] Napisać kontroler zgłoszeń HR
- [ ] Napisać kontroler panelu administratora
- [ ] Napisać kontroler użytkowników
- [ ] Napisać kontroler audytu
- [ ] Napisać kontroler logowania
- [ ] Napisać kontroler retencji / czyszczenia danych

## 15. Serwisy i logika aplikacyjna

- [ ] Napisać serwis tworzenia zgłoszenia
- [ ] Napisać serwis generowania tokenu
- [ ] Napisać serwis obsługi statusów zgłoszeń
- [ ] Napisać serwis obsługi wiadomości
- [ ] Napisać serwis obsługi załączników
- [ ] Napisać serwis audytu
- [ ] Napisać serwis retencji danych
- [ ] Napisać serwis uprawnień do zgłoszenia
- [ ] Napisać serwis operacji administracyjnych na użytkownikach
- [ ] Napisać helpery formatowania statusów i dat

## 16. Widoki Blade / HTML

- [ ] Napisać widok strony startowej
- [ ] Napisać widok instrukcji dla zgłaszającego
- [ ] Napisać widok formularza zgłoszenia
- [ ] Napisać widok potwierdzenia z tokenem
- [ ] Napisać widok powrotu do zgłoszenia po tokenie
- [ ] Napisać widok szczegółów zgłoszenia dla zgłaszającego
- [ ] Napisać widok listy zgłoszeń HR
- [ ] Napisać widok szczegółów zgłoszenia HR
- [ ] Napisać widok wiadomości HR
- [ ] Napisać widok dashboardu HR
- [ ] Napisać widok dashboardu administratora
- [ ] Napisać widok listy użytkowników
- [ ] Napisać widok formularza użytkownika
- [ ] Napisać widok listy audytu
- [ ] Napisać widok logowania
- [ ] Napisać widoki błędów

## 17. Style CSS

- [ ] Napisać style globalne aplikacji
- [ ] Napisać style formularzy
- [ ] Napisać style przycisków
- [ ] Napisać style tabel
- [ ] Napisać style kart informacyjnych
- [ ] Napisać style statusów zgłoszenia
- [ ] Napisać style komunikatów sukcesu i błędów
- [ ] Napisać style panelu HR
- [ ] Napisać style panelu administratora
- [ ] Napisać style widoku publicznego
- [ ] Napisać style responsywne dla urządzeń mobilnych

## 18. JavaScript / interakcje frontendowe

- [ ] Dodać potwierdzenie usunięcia wersji roboczej
- [ ] Dodać potwierdzenie zamknięcia zgłoszenia
- [ ] Dodać dynamiczne pokazywanie nazw wybranych załączników
- [ ] Dodać prostą walidację pól po stronie przeglądarki
- [ ] Dodać obsługę rozwijanych sekcji, jeśli występują
- [ ] Dodać obsługę menu mobilnego
- [ ] Dodać automatyczne ukrywanie komunikatów flash
- [ ] Dodać blokadę podwójnego wysłania formularza

## 19. Testy kodu aplikacyjnego

- [ ] Napisać test tworzenia zgłoszenia
- [ ] Napisać test zapisu wersji roboczej
- [ ] Napisać test wysłania zgłoszenia
- [ ] Napisać test dostępu po tokenie
- [ ] Napisać test błędnego tokenu
- [ ] Napisać test dodawania wiadomości
- [ ] Napisać test dodawania załącznika
- [ ] Napisać test pobierania załącznika
- [ ] Napisać test zmiany statusu przez HR
- [ ] Napisać test zamknięcia zgłoszenia
- [ ] Napisać test blokady zamkniętego zgłoszenia
- [ ] Napisać test logowania użytkownika
- [ ] Napisać test dostępu do panelu HR
- [ ] Napisać test dostępu do panelu administratora
- [ ] Napisać test operacji administracyjnych na użytkownikach
- [ ] Napisać test zapisu audytu
- [ ] Napisać test retencji wersji roboczych

## 20. Porządkowanie kodu

- [ ] Uporządkować nazwy kontrolerów
- [ ] Uporządkować nazwy serwisów
- [ ] Uporządkować nazwy widoków
- [ ] Wydzielić powtarzalne fragmenty Blade do komponentów
- [ ] Usunąć duplikaty kodu w kontrolerach
- [ ] Przenieść logikę biznesową z kontrolerów do serwisów
- [ ] Ujednolicić komunikaty błędów
- [ ] Ujednolicić komunikaty sukcesu
- [ ] Ujednolicić formatowanie dat
- [ ] Ujednolicić nazwy statusów
- [ ] Sprawdzić obsługę pustych stanów
- [ ] Sprawdzić obsługę wyjątków