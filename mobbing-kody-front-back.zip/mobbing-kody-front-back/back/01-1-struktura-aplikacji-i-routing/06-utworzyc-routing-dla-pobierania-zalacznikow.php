<?php

/*
Code catalog snippet for task:
Utworzyć routing dla pobierania załączników
Source: routes/web.php
This file is not a standalone Laravel class; copy the useful part into the real application file.
*/

use Illuminate\Support\Facades\Route;

Route::get('/hr/zgloszenia/{report}/zalaczniki/{attachment}', [HrReportController::class, 'downloadAttachment'])->name('hr.reports.attachments.download');
