<?php

/*
Code catalog snippet for task:
Utworzyć routing dla obsługi logowania
Source: routes/web.php
This file is not a standalone Laravel class; copy the useful part into the real application file.
*/

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\AuthController;
Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'login'])->name('login.post');
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
Route::get('/panel', [AuthController::class, 'panel'])->middleware('local.auth')->name('panel');
