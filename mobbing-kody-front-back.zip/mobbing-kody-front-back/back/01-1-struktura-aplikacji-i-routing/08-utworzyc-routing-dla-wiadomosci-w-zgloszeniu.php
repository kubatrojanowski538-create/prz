<?php

/*
Code catalog snippet for task:
Utworzyć routing dla wiadomości w zgłoszeniu
Source: routes/web.php
This file is not a standalone Laravel class; copy the useful part into the real application file.
*/

use Illuminate\Support\Facades\Route;

Route::post('/hr/zgloszenia/{report}/notatki', [HrReportController::class, 'addNote'])->name('hr.reports.notes');
