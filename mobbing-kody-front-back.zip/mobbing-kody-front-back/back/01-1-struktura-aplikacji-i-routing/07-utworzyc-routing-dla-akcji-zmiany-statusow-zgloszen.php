<?php

/*
Code catalog snippet for task:
Utworzyć routing dla akcji zmiany statusów zgłoszeń
Source: routes/web.php
This file is not a standalone Laravel class; copy the useful part into the real application file.
*/

use Illuminate\Support\Facades\Route;

Route::post('/hr/zgloszenia/{report}/status', [HrReportController::class, 'updateStatus'])->name('hr.reports.status');
