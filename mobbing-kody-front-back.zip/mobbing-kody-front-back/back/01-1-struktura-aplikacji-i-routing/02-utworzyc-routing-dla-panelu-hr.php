<?php

/*
Code catalog snippet for task:
Utworzyć routing dla panelu HR
Source: routes/web.php
This file is not a standalone Laravel class; copy the useful part into the real application file.
*/

use Illuminate\Support\Facades\Route;

Route::middleware(['local.auth', 'role:hr'])->prefix('hr')->name('hr.')->group(function () {
    Route::get('/zgloszenia', [HrReportController::class, 'index'])->name('reports.index');
    Route::get('/zgloszenia/{report}', [HrReportController::class, 'show'])->name('reports.show');
    Route::post('/zgloszenia/{report}/status', [HrReportController::class, 'updateStatus'])->name('reports.status');
    Route::post('/zgloszenia/{report}/notatki', [HrReportController::class, 'addNote'])->name('reports.notes');
    Route::get('/zgloszenia/{report}/zalaczniki/{attachment}', [HrReportController::class, 'downloadAttachment'])->name('reports.attachments.download');
});
