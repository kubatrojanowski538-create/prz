<?php

/*
Code catalog snippet for task:
Utworzyć routing dla panelu administratora
Source: routes/web.php
This file is not a standalone Laravel class; copy the useful part into the real application file.
*/

use Illuminate\Support\Facades\Route;

Route::middleware(['local.auth', 'role:admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/uzytkownicy', [UserController::class, 'index'])->name('users.index');
    Route::get('/uzytkownicy/nowy', [UserController::class, 'create'])->name('users.create');
    Route::post('/uzytkownicy', [UserController::class, 'store'])->name('users.store');
    Route::get('/uzytkownicy/{user}/edycja', [UserController::class, 'edit'])->name('users.edit');
    Route::put('/uzytkownicy/{user}', [UserController::class, 'update'])->name('users.update');

    Route::get('/kategorie', [CategoryController::class, 'index'])->name('categories.index');
    Route::get('/kategorie/nowa', [CategoryController::class, 'create'])->name('categories.create');
    Route::post('/kategorie', [CategoryController::class, 'store'])->name('categories.store');
    Route::get('/kategorie/{category}/edycja', [CategoryController::class, 'edit'])->name('categories.edit');
    Route::put('/kategorie/{category}', [CategoryController::class, 'update'])->name('categories.update');

    Route::get('/audyt', [AuditController::class, 'index'])->name('audit.index');
});
