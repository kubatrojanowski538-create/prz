<?php

/*
Code catalog snippet for task:
Utworzyć routing dla części publicznej aplikacji
Source: routes/web.php
This file is not a standalone Laravel class; copy the useful part into the real application file.
*/

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\PublicReportController;
Route::get('/', [PublicReportController::class, 'home'])->name('home');
Route::get('/zgloszenie/nowe', [PublicReportController::class, 'create'])->name('public.reports.create');
Route::post('/zgloszenie', [PublicReportController::class, 'store'])->name('public.reports.store');
Route::get('/status', [PublicReportController::class, 'statusLookupForm'])->name('public.status.lookup');
Route::post('/status', [PublicReportController::class, 'statusLookup'])->name('public.status.lookup.post');
Route::get('/status/{token}', [PublicReportController::class, 'statusTokenForm'])->name('public.status.token');
Route::post('/status/{token}', [PublicReportController::class, 'statusTokenShow'])->name('public.status.token.post');
    Route::post('/zgloszenia/{report}/status', [HrReportController::class, 'updateStatus'])->name('reports.status');
