<?php

/*
Code catalog snippet for task:
Dodać backendową obsługę uploadu załączników
Source: PublicReportController::store
This file is not a standalone Laravel class; copy the useful part into the real application file.
*/

use App\Models\Attachment;
use Illuminate\Support\Str;

foreach ($request->file('attachments', []) as $file) {
    if (! $file) {
        continue;
    }

    $originalName = $file->getClientOriginalName();
    $safeOriginalName = preg_replace('/[^A-Za-z0-9._ -]/', '_', $originalName) ?: 'attachment';
    $storedName = (string) Str::uuid().'_'.$safeOriginalName;
    $path = $file->storeAs('report-'.$report->report_id, $storedName, 'local');

    Attachment::create([
        'report_id' => $report->report_id,
        'file_name' => $originalName,
        'file_type' => $file->getClientMimeType(),
        'file_path' => $path,
        'size_bytes' => $file->getSize(),
    ]);
}
