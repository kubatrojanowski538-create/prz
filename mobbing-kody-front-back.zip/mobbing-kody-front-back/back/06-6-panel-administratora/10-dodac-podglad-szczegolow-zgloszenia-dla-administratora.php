<?php

/*
Code catalog snippet for task:
Dodać podgląd szczegółów zgłoszenia dla administratora
Source: PublicReportController + Hr ReportController
This file is not a standalone Laravel class; copy the useful part into the real application file.
*/

<?php

namespace App\Http\Controllers;

use App\Models\Attachment;
use App\Models\MobbingCategory;
use App\Models\Report;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class PublicReportController extends Controller
{
    public function home()
    {
        return view('public.home');
    }

    public function create()
    {
        $categories = MobbingCategory::query()
            ->where('is_active', true)
            ->orderBy('category_name')
            ->get();

        return view('public.create', [
            'categories' => $categories,
            'reporterRoles' => Report::reporterRoleOptions(),
        ]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'category_id' => ['nullable', 'exists:mobbing_categories,category_id'],
            'description' => ['required', 'string', 'min:20', 'max:20000'],
            'incident_date' => ['nullable', 'date'],
            'is_continuous' => ['nullable', 'boolean'],
            'place' => ['nullable', 'string', 'max:500'],
            'frequency' => ['nullable', 'string', 'max:500'],
            'accused_person' => ['nullable', 'string', 'max:1000'],
            'witnesses' => ['nullable', 'string', 'max:2000'],
            'reporter_role' => ['nullable', Rule::in(array_keys(Report::reporterRoleOptions()))],
            'previous_actions' => ['nullable', 'string', 'max:4000'],
            'truth_confirmed' => ['accepted'],
            'attachments.*' => ['nullable', 'file', 'max:20480'],
        ]);

        $pin = (string) random_int(100000, 999999);
        $token = Str::upper(Str::random(24));

        $report = DB::transaction(function () use ($request, $validated, $pin, $token) {
            $report = Report::create([
                'category_id' => $validated['category_id'] ?? null,
                'public_token' => $token,
                'public_pin_hash' => Hash::make($pin),
                'description' => $validated['description'],
                'status' => 'submitted',
                'incident_date' => $validated['incident_date'] ?? null,
                'is_continuous' => $request->boolean('is_continuous'),
                'place' => $validated['place'] ?? null,
                'frequency' => $validated['frequency'] ?? null,
                'accused_person' => $validated['accused_person'] ?? null,
                'witnesses' => $validated['witnesses'] ?? null,
                'reporter_role' => $validated['reporter_role'] ?? null,
                'previous_actions' => $validated['previous_actions'] ?? null,
                'truth_confirmed' => true,
                'report_date' => now(),
            ]);

            foreach ($request->file('attachments', []) as $file) {
                if (! $file) {
                    continue;
                }

                $originalName = $file->getClientOriginalName();
                $safeOriginalName = preg_replace('/[^A-Za-z0-9._ -]/', '_', $originalName) ?: 'attachment';
                $storedName = (string) Str::uuid().'_'.$safeOriginalName;
                $path = $file->storeAs('report-'.$report->report_id, $storedName, 'local');

                Attachment::create([
                    'report_id' => $report->report_id,
                    'file_name' => $originalName,
                    'file_type' => $file->getClientMimeType(),
                    'file_path' => $path,
                    'size_bytes' => $file->getSize(),
                ]);
            }

            return $report->fresh(['category', 'attachments']);
        });

        write_audit('report_submitted', [
            'report_id' => $report->report_id,
            'category_id' => $report->category_id,
            'attachments_count' => $report->attachments->count(),
        ]);

        return view('public.submitted', [
            'report' => $report,
            'pin' => $pin,
            'statusUrl' => route('public.status.token', $report->public_token),
        ]);
    }

    public function statusLookupForm()
    {
        return view('public.status_lookup');
    }

    public function statusLookup(Request $request)
    {
        $validated = $request->validate([
            'token' => ['required', 'string'],
            'pin' => ['required', 'string'],
        ]);

        return $this->showStatusByCredentials($validated['token'], $validated['pin']);
    }

    public function statusTokenForm(string $token)
    {
        return view('public.status_token', [
            'token' => $token,
        ]);
    }

    public function statusTokenShow(Request $request, string $token)
    {
        $validated = $request->validate([
            'pin' => ['required', 'string'],
        ]);

        return $this->showStatusByCredentials($token, $validated['pin']);
    }

    private function showStatusByCredentials(string $token, string $pin)
    {
        $report = Report::query()
            ->with('category')
            ->where('public_token', trim($token))
            ->first();

        if (! $report || ! Hash::check(trim($pin), $report->public_pin_hash)) {
            return back()
                ->withInput()
                ->withErrors(['pin' => 'Nie znaleziono zgłoszenia dla podanego tokenu i PIN-u.']);
        }

        write_audit('report_status_checked', [
            'report_id' => $report->report_id,
        ]);

        return view('public.status_show', [
            'report' => $report,
        ]);
    }
}


<?php

namespace App\Http\Controllers\Hr;

use App\Http\Controllers\Controller;
use App\Models\Attachment;
use App\Models\Report;
use App\Models\ReportNote;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;

class ReportController extends Controller
{
    public function index(Request $request)
    {
        $query = Report::query()
            ->with(['category'])
            ->withCount('attachments');

        if ($request->filled('status')) {
            $query->where('status', $request->string('status'));
        }

        if ($request->boolean('unread')) {
            $query->whereNull('read_at');
        }

        $sort = $request->input('sort', 'newest');
        $query->orderBy('created_at', $sort === 'oldest' ? 'asc' : 'desc');

        $reports = $query->paginate(15)->withQueryString();

        return view('hr.reports.index', [
            'reports' => $reports,
            'statuses' => Report::statusOptions(),
        ]);
    }

    public function show(Report $report)
    {
        if (! $report->read_at) {
            $report->update(['read_at' => now()]);
        }

        $report->load(['category', 'attachments', 'notes.user', 'hrUser']);

        write_audit('report_viewed_by_hr', [
            'report_id' => $report->report_id,
        ]);

        return view('hr.reports.show', [
            'report' => $report,
            'statuses' => Report::statusOptions(),
        ]);
    }

    public function updateStatus(Request $request, Report $report)
    {
        if ($report->isClosed()) {
            return back()->with('error', 'Zgłoszenie zakończone jest tylko do odczytu.');
        }

        $validated = $request->validate([
            'status' => ['required', Rule::in(array_keys(Report::statusOptions()))],
            'feedback_hr' => ['nullable', 'string', 'max:8000'],
        ]);

        $report->fill([
            'status' => $validated['status'],
            'feedback_hr' => $validated['feedback_hr'] ?? null,
            'user_id' => current_user()?->user_id,
            'update_date' => now(),
            'closed_at' => $validated['status'] === 'closed' ? now() : null,
        ])->save();

        write_audit('report_status_changed', [
            'report_id' => $report->report_id,
            'status' => $report->status,
        ]);

        return redirect()->route('hr.reports.show', $report)->with('success', 'Status zgłoszenia został zaktualizowany.');
    }

    public function addNote(Request $request, Report $report)
    {
        if ($report->isClosed()) {
            return back()->with('error', 'Zgłoszenie zakończone jest tylko do odczytu.');
        }

        $validated = $request->validate([
            'note' => ['required', 'string', 'max:8000'],
        ]);

        ReportNote::create([
            'report_id' => $report->report_id,
            'user_id' => current_user()?->user_id,
            'note' => $validated['note'],
        ]);

        write_audit('hr_note_added', [
            'report_id' => $report->report_id,
            'note' => '[redacted]',
        ]);

        return redirect()->route('hr.reports.show', $report)->with('success', 'Dodano notatkę wewnętrzną.');
    }

    public function downloadAttachment(Report $report, Attachment $attachment)
    {
        abort_unless($attachment->report_id === $report->report_id, 404);

        write_audit('attachment_downloaded_by_hr', [
            'report_id' => $report->report_id,
            'attachment_id' => $attachment->attachment_id,
        ]);

        if (! Storage::disk('local')->exists($attachment->file_path)) {
            return back()->with('error', 'Plik załącznika nie istnieje na dysku.');
        }

        return Storage::disk('local')->download($attachment->file_path, $attachment->file_name);
    }
}
