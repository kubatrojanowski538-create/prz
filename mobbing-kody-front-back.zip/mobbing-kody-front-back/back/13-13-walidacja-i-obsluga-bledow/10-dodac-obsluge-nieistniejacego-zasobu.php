<?php

/*
Code catalog snippet for task:
Dodać obsługę nieistniejącego zasobu
This file is not a standalone Laravel class; copy the useful part into the real application file.
*/

abort_unless($resource !== null, 404);
abort_if($report->isClosed(), 403, 'Closed reports are read-only.');
