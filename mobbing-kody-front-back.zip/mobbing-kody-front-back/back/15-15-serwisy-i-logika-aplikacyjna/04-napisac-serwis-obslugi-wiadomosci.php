<?php

/*
Code catalog snippet for task:
Napisać serwis obsługi wiadomości
Source: app/Http/Controllers/Hr/ReportController.php
This file is not a standalone Laravel class; copy the useful part into the real application file.
*/

final class Snippet
{
    public function addNote(Request $request, Report $report)
        {
            if ($report->isClosed()) {
                return back()->with('error', 'Zgłoszenie zakończone jest tylko do odczytu.');
            }

            $validated = $request->validate([
                'note' => ['required', 'string', 'max:8000'],
            ]);

            ReportNote::create([
                'report_id' => $report->report_id,
                'user_id' => current_user()?->user_id,
                'note' => $validated['note'],
            ]);

            write_audit('hr_note_added', [
                'report_id' => $report->report_id,
                'note' => '[redacted]',
            ]);

            return redirect()->route('hr.reports.show', $report)->with('success', 'Dodano notatkę wewnętrzną.');
        }
}
