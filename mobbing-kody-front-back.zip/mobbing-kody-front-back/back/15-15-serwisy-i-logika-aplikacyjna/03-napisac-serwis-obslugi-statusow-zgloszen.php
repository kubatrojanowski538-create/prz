<?php

/*
Code catalog snippet for task:
Napisać serwis obsługi statusów zgłoszeń
Source: app/Http/Controllers/Hr/ReportController.php
This file is not a standalone Laravel class; copy the useful part into the real application file.
*/

final class Snippet
{
    public function updateStatus(Request $request, Report $report)
        {
            if ($report->isClosed()) {
                return back()->with('error', 'Zgłoszenie zakończone jest tylko do odczytu.');
            }

            $validated = $request->validate([
                'status' => ['required', Rule::in(array_keys(Report::statusOptions()))],
                'feedback_hr' => ['nullable', 'string', 'max:8000'],
            ]);

            $report->fill([
                'status' => $validated['status'],
                'feedback_hr' => $validated['feedback_hr'] ?? null,
                'user_id' => current_user()?->user_id,
                'update_date' => now(),
                'closed_at' => $validated['status'] === 'closed' ? now() : null,
            ])->save();

            write_audit('report_status_changed', [
                'report_id' => $report->report_id,
                'status' => $report->status,
            ]);

            return redirect()->route('hr.reports.show', $report)->with('success', 'Status zgłoszenia został zaktualizowany.');
        }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Report extends Model
{
    protected $primaryKey = 'report_id';

    protected $fillable = [
        'user_id',
        'category_id',
        'public_token',
        'public_pin_hash',
        'description',
        'status',
        'feedback_hr',
        'incident_date',
        'is_continuous',
        'place',
        'frequency',
        'accused_person',
        'witnesses',
        'reporter_role',
        'previous_actions',
        'truth_confirmed',
        'read_at',
        'closed_at',
        'report_date',
        'update_date',
    ];

    protected $casts = [
        'incident_date' => 'date',
        'is_continuous' => 'boolean',
        'truth_confirmed' => 'boolean',
        'read_at' => 'datetime',
        'closed_at' => 'datetime',
        'report_date' => 'datetime',
        'update_date' => 'datetime',
    ];

    public static function statusOptions(): array
    {
        return [
            'submitted' => 'Wysłane',
            'in_review' => 'Rozpatrywane',
            'closed' => 'Zakończone',
        ];
    }

    public static function reporterRoleOptions(): array
    {
        return [
            'victim' => 'Jestem osobą pokrzywdzoną',
            'witness' => 'Jestem świadkiem',
            'other' => 'Zgłaszam w innej roli',
        ];
    }

    public function statusLabel(): string
    {
        return self::statusOptions()[$this->status] ?? $this->status;
    }

    public function reporterRoleLabel(): string
    {
        return self::reporterRoleOptions()[$this->reporter_role] ?? 'Nie podano';
    }

    public function isClosed(): bool
    {
        return $this->status === 'closed';
    }

    public function category(): BelongsTo
    {
        return $this->belongsTo(MobbingCategory::class, 'category_id', 'category_id');
    }

    public function hrUser(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id', 'user_id');
    }

    public function attachments(): HasMany
    {
        return $this->hasMany(Attachment::class, 'report_id', 'report_id');
    }

    public function notes(): HasMany
    {
        return $this->hasMany(ReportNote::class, 'report_id', 'report_id');
    }
}
