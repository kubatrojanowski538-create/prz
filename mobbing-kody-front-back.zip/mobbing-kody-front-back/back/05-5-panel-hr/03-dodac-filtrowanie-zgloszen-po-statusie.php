<?php

/*
Code catalog snippet for task:
Dodać filtrowanie zgłoszeń po statusie
Source: app/Http/Controllers/Hr/ReportController.php
This file is not a standalone Laravel class; copy the useful part into the real application file.
*/

final class Snippet
{
    public function index(Request $request)
        {
            $query = Report::query()
                ->with(['category'])
                ->withCount('attachments');

            if ($request->filled('status')) {
                $query->where('status', $request->string('status'));
            }

            if ($request->boolean('unread')) {
                $query->whereNull('read_at');
            }

            $sort = $request->input('sort', 'newest');
            $query->orderBy('created_at', $sort === 'oldest' ? 'asc' : 'desc');

            $reports = $query->paginate(15)->withQueryString();

            return view('hr.reports.index', [
                'reports' => $reports,
                'statuses' => Report::statusOptions(),
            ]);
        }
}
