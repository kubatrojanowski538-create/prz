<?php

/*
Code catalog snippet for task:
Stworzyć obsługę usuwania wersji roboczej
Source: public/js/app.js
This file is not a standalone Laravel class; copy the useful part into the real application file.
*/

// The current demo stores drafts in browser localStorage, not in the backend.
(function () {
    const panicTarget = 'https://www.gov.pl/';

    window.panicExit = function () {
        try {
            window.location.replace(panicTarget);
        } catch (error) {
            window.location.href = panicTarget;
        }
    };

    function draftKey(form) {
        return form.getAttribute('data-draft-key') || 'anonymous-report-draft';
    }

    function serializeDraft(form) {
        const data = {};
        const fields = form.querySelectorAll('input, textarea, select');

        fields.forEach((field) => {
            if (!field.name || field.type === 'file' || field.name === '_token') {
                return;
            }

            if (field.type === 'checkbox') {
                data[field.name] = field.checked;
                return;
            }

            data[field.name] = field.value;
        });

        return data;
    }

    function restoreDraft(form) {
        const raw = window.localStorage.getItem(draftKey(form));
        if (!raw) {
            return;
        }

        try {
            const data = JSON.parse(raw);
            Object.keys(data).forEach((name) => {
                const field = form.querySelector(`[name="${CSS.escape(name)}"]`);
                if (!field) {
                    return;
                }

                if (field.type === 'checkbox') {
                    field.checked = Boolean(data[name]);
                } else {
                    field.value = data[name];
                }
            });
        } catch (error) {
            window.localStorage.removeItem(draftKey(form));
        }
    }

    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('[data-panic-button]').forEach((button) => {
            button.addEventListener('click', window.panicExit);
        });

        const form = document.querySelector('[data-draft-form]');
        if (!form) {
            return;
        }

        restoreDraft(form);

        const saveButton = document.querySelector('[data-save-draft]');
        const deleteButton = document.querySelector('[data-delete-draft]');
        const draftMessage = document.querySelector('[data-draft-message]');

        if (saveButton) {
            saveButton.addEventListener('click', function () {
                window.localStorage.setItem(draftKey(form), JSON.stringify(serializeDraft(form)));
                if (draftMessage) {
                    draftMessage.textContent = 'Wersja robocza została zapisana lokalnie w tej przeglądarce.';
                }
            });
        }

        if (deleteButton) {
            deleteButton.addEventListener('click', function () {
                window.localStorage.removeItem(draftKey(form));
                if (draftMessage) {
                    draftMessage.textContent = 'Wersja robocza została usunięta z tego urządzenia.';
                }
            });
        }

        form.addEventListener('submit', function () {
            window.localStorage.removeItem(draftKey(form));
        });
    });
})();
