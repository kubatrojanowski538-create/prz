<?php

/*
Code catalog snippet for task:
Dodać walidację formularza zgłoszenia po stronie backendu
Source: app/Http/Controllers/PublicReportController.php
This file is not a standalone Laravel class; copy the useful part into the real application file.
*/

use Illuminate\Validation\Rule;
use App\Models\Report;

$validated = $request->validate([
    'category_id' => ['nullable', 'exists:mobbing_categories,category_id'],
    'description' => ['required', 'string', 'min:20', 'max:20000'],
    'incident_date' => ['nullable', 'date'],
    'is_continuous' => ['nullable', 'boolean'],
    'place' => ['nullable', 'string', 'max:500'],
    'frequency' => ['nullable', 'string', 'max:500'],
    'accused_person' => ['nullable', 'string', 'max:1000'],
    'witnesses' => ['nullable', 'string', 'max:2000'],
    'reporter_role' => ['nullable', Rule::in(array_keys(Report::reporterRoleOptions()))],
    'previous_actions' => ['nullable', 'string', 'max:4000'],
    'truth_confirmed' => ['accepted'],
    'attachments.*' => ['nullable', 'file', 'max:20480'],
]);
