<?php

/*
Code catalog snippet for task:
Napisać test dostępu po tokenie
Source: app/Http/Controllers/PublicReportController.php
This file is not a standalone Laravel class; copy the useful part into the real application file.
*/

final class Snippet
{
    private function showStatusByCredentials(string $token, string $pin)
        {
            $report = Report::query()
                ->with('category')
                ->where('public_token', trim($token))
                ->first();

            if (! $report || ! Hash::check(trim($pin), $report->public_pin_hash)) {
                return back()
                    ->withInput()
                    ->withErrors(['pin' => 'Nie znaleziono zgłoszenia dla podanego tokenu i PIN-u.']);
            }

            write_audit('report_status_checked', [
                'report_id' => $report->report_id,
            ]);

            return view('public.status_show', [
                'report' => $report,
            ]);
        }
}
