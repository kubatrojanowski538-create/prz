<?php

/*
Code catalog snippet for task:
Napisać test zmiany statusu przez HR
Source: app/Http/Controllers/Hr/ReportController.php
This file is not a standalone Laravel class; copy the useful part into the real application file.
*/

final class Snippet
{
    public function updateStatus(Request $request, Report $report)
        {
            if ($report->isClosed()) {
                return back()->with('error', 'Zgłoszenie zakończone jest tylko do odczytu.');
            }

            $validated = $request->validate([
                'status' => ['required', Rule::in(array_keys(Report::statusOptions()))],
                'feedback_hr' => ['nullable', 'string', 'max:8000'],
            ]);

            $report->fill([
                'status' => $validated['status'],
                'feedback_hr' => $validated['feedback_hr'] ?? null,
                'user_id' => current_user()?->user_id,
                'update_date' => now(),
                'closed_at' => $validated['status'] === 'closed' ? now() : null,
            ])->save();

            write_audit('report_status_changed', [
                'report_id' => $report->report_id,
                'status' => $report->status,
            ]);

            return redirect()->route('hr.reports.show', $report)->with('success', 'Status zgłoszenia został zaktualizowany.');
        }
}
