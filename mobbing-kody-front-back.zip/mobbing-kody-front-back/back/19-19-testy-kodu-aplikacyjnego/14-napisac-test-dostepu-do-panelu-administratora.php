<?php

/*
Code catalog snippet for task:
Napisać test dostępu do panelu administratora
This file is not a standalone Laravel class; copy the useful part into the real application file.
*/

use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

final class NapisacTestDostepuDoPaneluAdministrTest extends TestCase
{
    public function test_user_can_login_and_is_redirected_by_role(): void
    {
        $user = User::factory()->create([
            'login' => 'hr',
            'password_hash' => Hash::make('secret123'),
            'role' => 'hr',
            'is_active' => true,
        ]);

        $this->post('/login', [
            'login' => 'hr',
            'password' => 'secret123',
        ])->assertRedirect('/panel');

        $this->assertEquals($user->user_id, session('auth_user_id'));
    }
}
