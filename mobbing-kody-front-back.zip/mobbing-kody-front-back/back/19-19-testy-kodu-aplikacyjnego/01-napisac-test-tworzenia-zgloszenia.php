<?php

/*
Code catalog snippet for task:
Napisać test tworzenia zgłoszenia
This file is not a standalone Laravel class; copy the useful part into the real application file.
*/

use Tests\TestCase;

final class NapisacTestTworzeniaZgloszeniaTest extends TestCase
{
    public function test_report_flow_works(): void
    {
        $response = $this->post('/zgloszenie', [
            'description' => str_repeat('Opis zdarzenia. ', 4),
            'truth_confirmed' => '1',
        ]);

        $response->assertOk();
        $this->assertDatabaseHas('reports', ['status' => 'submitted']);
    }
}
