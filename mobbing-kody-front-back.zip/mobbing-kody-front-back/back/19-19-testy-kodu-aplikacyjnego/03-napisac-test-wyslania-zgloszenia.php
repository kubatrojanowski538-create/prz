<?php

/*
Code catalog snippet for task:
Napisać test wysłania zgłoszenia
Source: app/Http/Controllers/PublicReportController.php
This file is not a standalone Laravel class; copy the useful part into the real application file.
*/

final class Snippet
{
    public function store(Request $request)
        {
            $validated = $request->validate([
                'category_id' => ['nullable', 'exists:mobbing_categories,category_id'],
                'description' => ['required', 'string', 'min:20', 'max:20000'],
                'incident_date' => ['nullable', 'date'],
                'is_continuous' => ['nullable', 'boolean'],
                'place' => ['nullable', 'string', 'max:500'],
                'frequency' => ['nullable', 'string', 'max:500'],
                'accused_person' => ['nullable', 'string', 'max:1000'],
                'witnesses' => ['nullable', 'string', 'max:2000'],
                'reporter_role' => ['nullable', Rule::in(array_keys(Report::reporterRoleOptions()))],
                'previous_actions' => ['nullable', 'string', 'max:4000'],
                'truth_confirmed' => ['accepted'],
                'attachments.*' => ['nullable', 'file', 'max:20480'],
            ]);

            $pin = (string) random_int(100000, 999999);
            $token = Str::upper(Str::random(24));

            $report = DB::transaction(function () use ($request, $validated, $pin, $token) {
                $report = Report::create([
                    'category_id' => $validated['category_id'] ?? null,
                    'public_token' => $token,
                    'public_pin_hash' => Hash::make($pin),
                    'description' => $validated['description'],
                    'status' => 'submitted',
                    'incident_date' => $validated['incident_date'] ?? null,
                    'is_continuous' => $request->boolean('is_continuous'),
                    'place' => $validated['place'] ?? null,
                    'frequency' => $validated['frequency'] ?? null,
                    'accused_person' => $validated['accused_person'] ?? null,
                    'witnesses' => $validated['witnesses'] ?? null,
                    'reporter_role' => $validated['reporter_role'] ?? null,
                    'previous_actions' => $validated['previous_actions'] ?? null,
                    'truth_confirmed' => true,
                    'report_date' => now(),
                ]);

                foreach ($request->file('attachments', []) as $file) {
                    if (! $file) {
                        continue;
                    }

                    $originalName = $file->getClientOriginalName();
                    $safeOriginalName = preg_replace('/[^A-Za-z0-9._ -]/', '_', $originalName) ?: 'attachment';
                    $storedName = (string) Str::uuid().'_'.$safeOriginalName;
                    $path = $file->storeAs('report-'.$report->report_id, $storedName, 'local');

                    Attachment::create([
                        'report_id' => $report->report_id,
                        'file_name' => $originalName,
                        'file_type' => $file->getClientMimeType(),
                        'file_path' => $path,
                        'size_bytes' => $file->getSize(),
                    ]);
                }

                return $report->fresh(['category', 'attachments']);
            });

            write_audit('report_submitted', [
                'report_id' => $report->report_id,
                'category_id' => $report->category_id,
                'attachments_count' => $report->attachments->count(),
            ]);

            return view('public.submitted', [
                'report' => $report,
                'pin' => $pin,
                'statusUrl' => route('public.status.token', $report->public_token),
            ]);
        }
}
