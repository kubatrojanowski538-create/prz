<?php

/*
Code catalog snippet for task:
Napisać kontroler retencji / czyszczenia danych
Source: app/Console/Commands/PurgeClosedReports.php
This file is not a standalone Laravel class; copy the useful part into the real application file.
*/

<?php

namespace App\Console\Commands;

use App\Models\Report;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;

class PurgeClosedReports extends Command
{
    protected $signature = 'reports:purge-closed {--days= : Number of days after closing a report}';

    protected $description = 'Permanently deletes closed reports older than the configured retention period.';

    public function handle(): int
    {
        $days = (int) ($this->option('days') ?: env('RETENTION_DAYS_AFTER_CLOSED', 1825));
        $threshold = now()->subDays($days);
        $deleted = 0;

        Report::query()
            ->where('status', 'closed')
            ->whereNotNull('closed_at')
            ->where('closed_at', '<', $threshold)
            ->with('attachments')
            ->chunkById(50, function ($reports) use (&$deleted): void {
                foreach ($reports as $report) {
                    foreach ($report->attachments as $attachment) {
                        Storage::disk('local')->delete($attachment->file_path);
                    }

                    Storage::disk('local')->deleteDirectory('report-'.$report->report_id);
                    $report->delete();
                    $deleted++;
                }
            }, 'report_id');

        $this->info("Deleted {$deleted} closed report(s).");

        return self::SUCCESS;
    }
}
