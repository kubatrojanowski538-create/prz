<?php

/*
Code catalog snippet for task:
Napisać kontroler wiadomości
This file is not a standalone Laravel class; copy the useful part into the real application file.
*/

use App\Models\Report;
use Illuminate\Http\Request;

final class ReportMessageSnippet
{
    public function addPublicMessage(Request $request, Report $report): void
    {
        abort_if($report->isClosed(), 403, 'Closed reports are read-only.');

        $validated = $request->validate([
            'message' => ['required', 'string', 'max:8000'],
        ]);

        // In the real application this would use a ReportMessage model/table.
        $report->notes()->create([
            'user_id' => null,
            'note' => '[PUBLIC] '.$validated['message'],
        ]);

        write_audit('public_message_added', [
            'report_id' => $report->report_id,
            'message' => '[redacted]',
        ]);
    }

    public function addHrMessage(Request $request, Report $report): void
    {
        abort_if($report->isClosed(), 403, 'Closed reports are read-only.');

        $validated = $request->validate([
            'message' => ['required', 'string', 'max:8000'],
        ]);

        $report->notes()->create([
            'user_id' => current_user()?->user_id,
            'note' => '[HR] '.$validated['message'],
        ]);

        write_audit('hr_message_added', [
            'report_id' => $report->report_id,
            'message' => '[redacted]',
        ]);
    }
}
