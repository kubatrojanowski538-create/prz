<?php

/*
Code catalog snippet for task:
Napisać kontroler audytu
Source: app/Http/Controllers/Admin/AuditController.php
This file is not a standalone Laravel class; copy the useful part into the real application file.
*/

<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use Illuminate\Http\Request;

class AuditController extends Controller
{
    public function index(Request $request)
    {
        $query = AuditLog::query()->with('user')->latest();

        if ($request->filled('action')) {
            $query->where('action', 'like', '%'.$request->string('action').'%');
        }

        return view('admin.audit.index', [
            'logs' => $query->paginate(30)->withQueryString(),
        ]);
    }
}
