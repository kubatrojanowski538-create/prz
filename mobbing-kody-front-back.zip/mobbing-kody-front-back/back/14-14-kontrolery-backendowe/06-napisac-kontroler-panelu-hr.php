<?php

/*
Code catalog snippet for task:
Napisać kontroler panelu HR
Source: app/Http/Controllers/Hr/ReportController.php
This file is not a standalone Laravel class; copy the useful part into the real application file.
*/

<?php

namespace App\Http\Controllers\Hr;

use App\Http\Controllers\Controller;
use App\Models\Attachment;
use App\Models\Report;
use App\Models\ReportNote;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;

class ReportController extends Controller
{
    public function index(Request $request)
    {
        $query = Report::query()
            ->with(['category'])
            ->withCount('attachments');

        if ($request->filled('status')) {
            $query->where('status', $request->string('status'));
        }

        if ($request->boolean('unread')) {
            $query->whereNull('read_at');
        }

        $sort = $request->input('sort', 'newest');
        $query->orderBy('created_at', $sort === 'oldest' ? 'asc' : 'desc');

        $reports = $query->paginate(15)->withQueryString();

        return view('hr.reports.index', [
            'reports' => $reports,
            'statuses' => Report::statusOptions(),
        ]);
    }

    public function show(Report $report)
    {
        if (! $report->read_at) {
            $report->update(['read_at' => now()]);
        }

        $report->load(['category', 'attachments', 'notes.user', 'hrUser']);

        write_audit('report_viewed_by_hr', [
            'report_id' => $report->report_id,
        ]);

        return view('hr.reports.show', [
            'report' => $report,
            'statuses' => Report::statusOptions(),
        ]);
    }

    public function updateStatus(Request $request, Report $report)
    {
        if ($report->isClosed()) {
            return back()->with('error', 'Zgłoszenie zakończone jest tylko do odczytu.');
        }

        $validated = $request->validate([
            'status' => ['required', Rule::in(array_keys(Report::statusOptions()))],
            'feedback_hr' => ['nullable', 'string', 'max:8000'],
        ]);

        $report->fill([
            'status' => $validated['status'],
            'feedback_hr' => $validated['feedback_hr'] ?? null,
            'user_id' => current_user()?->user_id,
            'update_date' => now(),
            'closed_at' => $validated['status'] === 'closed' ? now() : null,
        ])->save();

        write_audit('report_status_changed', [
            'report_id' => $report->report_id,
            'status' => $report->status,
        ]);

        return redirect()->route('hr.reports.show', $report)->with('success', 'Status zgłoszenia został zaktualizowany.');
    }

    public function addNote(Request $request, Report $report)
    {
        if ($report->isClosed()) {
            return back()->with('error', 'Zgłoszenie zakończone jest tylko do odczytu.');
        }

        $validated = $request->validate([
            'note' => ['required', 'string', 'max:8000'],
        ]);

        ReportNote::create([
            'report_id' => $report->report_id,
            'user_id' => current_user()?->user_id,
            'note' => $validated['note'],
        ]);

        write_audit('hr_note_added', [
            'report_id' => $report->report_id,
            'note' => '[redacted]',
        ]);

        return redirect()->route('hr.reports.show', $report)->with('success', 'Dodano notatkę wewnętrzną.');
    }

    public function downloadAttachment(Report $report, Attachment $attachment)
    {
        abort_unless($attachment->report_id === $report->report_id, 404);

        write_audit('attachment_downloaded_by_hr', [
            'report_id' => $report->report_id,
            'attachment_id' => $attachment->attachment_id,
        ]);

        if (! Storage::disk('local')->exists($attachment->file_path)) {
            return back()->with('error', 'Plik załącznika nie istnieje na dysku.');
        }

        return Storage::disk('local')->download($attachment->file_path, $attachment->file_name);
    }
}
