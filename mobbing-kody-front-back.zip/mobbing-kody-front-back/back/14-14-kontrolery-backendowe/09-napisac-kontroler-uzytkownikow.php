<?php

/*
Code catalog snippet for task:
Napisać kontroler użytkowników
Source: app/Http/Controllers/Admin/UserController.php
This file is not a standalone Laravel class; copy the useful part into the real application file.
*/

<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

class UserController extends Controller
{
    public function index()
    {
        return view('admin.users.index', [
            'users' => User::query()->orderBy('role')->orderBy('login')->get(),
        ]);
    }

    public function create()
    {
        return view('admin.users.form', [
            'user' => new User(['role' => 'hr', 'is_active' => true]),
            'mode' => 'create',
        ]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'login' => ['required', 'string', 'max:100', 'unique:users,login'],
            'password' => ['required', 'string', 'min:8'],
            'role' => ['required', Rule::in(['hr', 'admin'])],
            'is_active' => ['nullable', 'boolean'],
        ]);

        $user = User::create([
            'login' => $validated['login'],
            'password_hash' => Hash::make($validated['password']),
            'role' => $validated['role'],
            'is_active' => $request->boolean('is_active'),
        ]);

        write_audit('admin_user_created', [
            'created_user_id' => $user->user_id,
            'role' => $user->role,
        ]);

        return redirect()->route('admin.users.index')->with('success', 'Utworzono konto.');
    }

    public function edit(User $user)
    {
        return view('admin.users.form', [
            'user' => $user,
            'mode' => 'edit',
        ]);
    }

    public function update(Request $request, User $user)
    {
        $validated = $request->validate([
            'login' => ['required', 'string', 'max:100', Rule::unique('users', 'login')->ignore($user->user_id, 'user_id')],
            'password' => ['nullable', 'string', 'min:8'],
            'role' => ['required', Rule::in(['hr', 'admin'])],
            'is_active' => ['nullable', 'boolean'],
        ]);

        $data = [
            'login' => $validated['login'],
            'role' => $validated['role'],
            'is_active' => $request->boolean('is_active'),
        ];

        if (! empty($validated['password'])) {
            $data['password_hash'] = Hash::make($validated['password']);
        }

        $user->update($data);

        write_audit('admin_user_updated', [
            'updated_user_id' => $user->user_id,
            'role' => $user->role,
            'is_active' => $user->is_active,
        ]);

        return redirect()->route('admin.users.index')->with('success', 'Zaktualizowano konto.');
    }
}
