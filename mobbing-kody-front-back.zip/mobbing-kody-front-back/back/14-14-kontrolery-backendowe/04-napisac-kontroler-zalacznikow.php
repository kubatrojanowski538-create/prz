<?php

/*
Code catalog snippet for task:
Napisać kontroler załączników
Source: HrReportController / PublicReportController
This file is not a standalone Laravel class; copy the useful part into the real application file.
*/

final class Snippet
{
    public function downloadAttachment(Report $report, Attachment $attachment)
        {
            abort_unless($attachment->report_id === $report->report_id, 404);

            write_audit('attachment_downloaded_by_hr', [
                'report_id' => $report->report_id,
                'attachment_id' => $attachment->attachment_id,
            ]);

            if (! Storage::disk('local')->exists($attachment->file_path)) {
                return back()->with('error', 'Plik załącznika nie istnieje na dysku.');
            }

            return Storage::disk('local')->download($attachment->file_path, $attachment->file_name);
        }

    foreach ($request->file('attachments', []) as $file) {
        if (! $file) {
            continue;
        }

        $originalName = $file->getClientOriginalName();
        $safeOriginalName = preg_replace('/[^A-Za-z0-9._ -]/', '_', $originalName) ?: 'attachment';
        $storedName = (string) Str::uuid().'_'.$safeOriginalName;
        $path = $file->storeAs('report-'.$report->report_id, $storedName, 'local');

        Attachment::create([
            'report_id' => $report->report_id,
            'file_name' => $originalName,
            'file_type' => $file->getClientMimeType(),
            'file_path' => $path,
            'size_bytes' => $file->getSize(),
        ]);
    }
}
