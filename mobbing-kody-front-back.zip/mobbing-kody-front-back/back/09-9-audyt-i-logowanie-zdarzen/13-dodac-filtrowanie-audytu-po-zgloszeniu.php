<?php

/*
Code catalog snippet for task:
Dodać filtrowanie audytu po zgłoszeniu
Source: app/helpers.php + app/Http/Controllers/Admin/AuditController.php
This file is not a standalone Laravel class; copy the useful part into the real application file.
*/

<?php

use App\Models\AuditLog;
use App\Models\User;
use Illuminate\Support\Arr;

if (! function_exists('current_user')) {
    function current_user(): ?User
    {
        $id = session('auth_user_id');

        if (! $id) {
            return null;
        }

        return User::find($id);
    }
}

if (! function_exists('redact_audit_metadata')) {
    function redact_audit_metadata(array $metadata): array
    {
        $sensitiveKeys = [
            'description',
            'feedback_hr',
            'note',
            'notes',
            'file_path',
            'public_token',
            'public_pin',
            'public_pin_hash',
        ];

        foreach ($sensitiveKeys as $key) {
            if (Arr::has($metadata, $key)) {
                Arr::set($metadata, $key, '[redacted]');
            }
        }

        return $metadata;
    }
}

if (! function_exists('write_audit')) {
    function write_audit(string $action, array $metadata = [], ?int $userId = null): void
    {
        try {
            $request = request();
            $ip = $request ? $request->ip() : null;

            AuditLog::create([
                'user_id' => $userId ?? session('auth_user_id'),
                'action' => $action,
                'ip_hash' => $ip ? hash('sha256', $ip) : null,
                'metadata' => redact_audit_metadata($metadata),
            ]);
        } catch (Throwable $exception) {
            // Audit logging must not break the main user action in this demo application.
            report($exception);
        }
    }
}


<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use Illuminate\Http\Request;

class AuditController extends Controller
{
    public function index(Request $request)
    {
        $query = AuditLog::query()->with('user')->latest();

        if ($request->filled('action')) {
            $query->where('action', 'like', '%'.$request->string('action').'%');
        }

        return view('admin.audit.index', [
            'logs' => $query->paginate(30)->withQueryString(),
        ]);
    }
}
