<?php

/*
Code catalog snippet for task:
Dodać zapisywanie zdarzenia pobrania załącznika
Source: app/Http/Controllers/Hr/ReportController.php
This file is not a standalone Laravel class; copy the useful part into the real application file.
*/

final class Snippet
{
    public function downloadAttachment(Report $report, Attachment $attachment)
        {
            abort_unless($attachment->report_id === $report->report_id, 404);

            write_audit('attachment_downloaded_by_hr', [
                'report_id' => $report->report_id,
                'attachment_id' => $attachment->attachment_id,
            ]);

            if (! Storage::disk('local')->exists($attachment->file_path)) {
                return back()->with('error', 'Plik załącznika nie istnieje na dysku.');
            }

            return Storage::disk('local')->download($attachment->file_path, $attachment->file_name);
        }
}
