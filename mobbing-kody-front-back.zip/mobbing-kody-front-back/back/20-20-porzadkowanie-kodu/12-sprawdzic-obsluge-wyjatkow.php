<?php

/*
Code catalog snippet for task:
Sprawdzić obsługę wyjątków
This file is not a standalone Laravel class; copy the useful part into the real application file.
*/

use Illuminate\Support\Facades\Validator;

final class SprawdzicObslugeWyjatkowSnippet
{
    public function handle(array $input): array
    {
        // Validate the incoming data before changing application state.
        $validated = validator($input, [
            'report_id' => ['nullable', 'integer'],
            'value' => ['nullable'],
        ])->validate();

        // Keep domain rules outside controllers in the final application.
        return [
            'ok' => true,
            'data' => $validated,
        ];
    }
}
