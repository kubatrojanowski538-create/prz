<?php

/*
Code catalog snippet for task:
Stworzyć widok logowania użytkownika wewnętrznego
Source: app/Http/Controllers/AuthController.php
This file is not a standalone Laravel class; copy the useful part into the real application file.
*/

<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public function showLogin()
    {
        if (current_user()) {
            return redirect()->route('panel');
        }

        return view('auth.login');
    }

    public function login(Request $request)
    {
        $validated = $request->validate([
            'login' => ['required', 'string'],
            'password' => ['required', 'string'],
        ]);

        $user = User::query()->where('login', $validated['login'])->first();

        if (! $user || ! $user->is_active || ! Hash::check($validated['password'], $user->password_hash)) {
            write_audit('login_failed', ['login' => $validated['login']]);

            return back()
                ->withInput(['login' => $validated['login']])
                ->withErrors(['login' => 'Nieprawidłowy login lub hasło albo konto jest zablokowane.']);
        }

        $request->session()->regenerate();
        session(['auth_user_id' => $user->user_id]);

        $user->update(['last_login_at' => now()]);

        write_audit('login_success', [
            'user_id' => $user->user_id,
            'role' => $user->role,
        ], $user->user_id);

        return redirect()->route('panel');
    }

    public function panel()
    {
        $user = current_user();

        return match ($user?->role) {
            'admin' => redirect()->route('admin.users.index'),
            'hr' => redirect()->route('hr.reports.index'),
            default => abort(403),
        };
    }

    public function logout(Request $request)
    {
        write_audit('logout', ['user_id' => session('auth_user_id')]);

        $request->session()->forget('auth_user_id');
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('home')->with('success', 'Wylogowano.');
    }
}


<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class AuthenticateLocal
{
    public function handle(Request $request, Closure $next): Response
    {
        if (! current_user()) {
            return redirect()->route('login')->with('error', 'Zaloguj się, aby przejść do panelu.');
        }

        return $next($request);
    }
}


<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureRole
{
    public function handle(Request $request, Closure $next, string ...$roles): Response
    {
        $user = current_user();

        if (! $user || ! in_array($user->role, $roles, true)) {
            abort(403, 'Brak uprawnień do tej części systemu.');
        }

        return $next($request);
    }
}
