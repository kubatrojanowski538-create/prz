<?php

/*
Code catalog snippet for task:
Dodać zabezpieczenie akcji backendowych przed nieuprawnionym użyciem
Source: app/Http/Middleware/EnsureRole.php
This file is not a standalone Laravel class; copy the useful part into the real application file.
*/

<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureRole
{
    public function handle(Request $request, Closure $next, string ...$roles): Response
    {
        $user = current_user();

        if (! $user || ! in_array($user->role, $roles, true)) {
            abort(403, 'Brak uprawnień do tej części systemu.');
        }

        return $next($request);
    }
}
