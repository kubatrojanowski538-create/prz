# Taski frontendowe pokryte w `frontend.blade.php`

Ten folder zawiera jeden zbiorczy plik frontendu z sekcjami Blade, CSS i JavaScript.

## 2. Część publiczna – zgłaszający

- Stworzyć stronę startową dla zgłaszającego
- Stworzyć widok instrukcji / informacji o zgłaszaniu mobbingu
- Stworzyć formularz tworzenia anonimowego zgłoszenia
- Dodać walidację formularza zgłoszenia po stronie frontendu
- Stworzyć widok potwierdzenia utworzenia zgłoszenia
- Stworzyć formularz powrotu do zgłoszenia po tokenie
- Stworzyć widok zgłoszenia dostępny po tokenie
- Dodać komunikaty błędów i sukcesu dla zgłaszającego

## 3. Załączniki

- Dodać obsługę wyboru plików w formularzu zgłoszenia

## 4. Komunikacja zgłaszający – HR

- Stworzyć widok wiadomości przy zgłoszeniu dla zgłaszającego
- Stworzyć formularz dodawania wiadomości przez zgłaszającego
- Stworzyć widok wiadomości przy zgłoszeniu dla HR
- Stworzyć formularz dodawania wiadomości przez HR
- Dodać odświeżanie widoku wiadomości po zapisaniu odpowiedzi

## 5. Panel HR

- Stworzyć widok szczegółów zgłoszenia dla HR
- Dodać komunikaty akcji w panelu HR

## 6. Panel administratora

- Stworzyć formularz dodawania użytkownika
- Stworzyć formularz edycji użytkownika
- Dodać walidację formularzy użytkowników

## 7. Logowanie i autoryzacja

- Dodać ochronę przed dostępem do nieuprawnionych widoków

## 11. Frontend wspólny

- Przygotować główny layout aplikacji
- Przygotować layout części publicznej
- Przygotować layout panelu HR
- Przygotować layout panelu administratora
- Przygotować komponent nagłówka
- Przygotować komponent menu
- Przygotować komponent stopki
- Przygotować komponent komunikatów flash
- Przygotować komponent kart / paneli
- Przygotować komponent tabel
- Przygotować komponent formularzy
- Przygotować komponent status badge
- Przygotować komponent pustego stanu listy
- Przygotować komponent potwierdzenia akcji

## 12. Responsywność i UX

- Dostosować stronę publiczną do urządzeń mobilnych
- Dostosować formularz zgłoszenia do małych ekranów
- Dostosować panel HR do mniejszych ekranów
- Dostosować panel administratora do mniejszych ekranów
- Dodać czytelne odstępy i skalowanie elementów
- Dodać responsywne tabele lub alternatywny widok kart
- Dodać stany hover / focus dla elementów interaktywnych
- Dodać widoczne komunikaty błędów formularzy
- Dodać potwierdzenia dla akcji destrukcyjnych
- Uporządkować kolejność pól formularzy

## 13. Walidacja i obsługa błędów

- Dodać walidację formularzy użytkowników

## 16. Widoki Blade / HTML

- Napisać widok strony startowej
- Napisać widok instrukcji dla zgłaszającego
- Napisać widok formularza zgłoszenia
- Napisać widok potwierdzenia z tokenem
- Napisać widok powrotu do zgłoszenia po tokenie
- Napisać widok szczegółów zgłoszenia dla zgłaszającego
- Napisać widok listy zgłoszeń HR
- Napisać widok szczegółów zgłoszenia HR
- Napisać widok wiadomości HR
- Napisać widok dashboardu HR
- Napisać widok dashboardu administratora
- Napisać widok listy użytkowników
- Napisać widok formularza użytkownika
- Napisać widok listy audytu
- Napisać widok logowania
- Napisać widoki błędów

## 17. Style CSS

- Napisać style globalne aplikacji
- Napisać style formularzy
- Napisać style przycisków
- Napisać style tabel
- Napisać style kart informacyjnych
- Napisać style statusów zgłoszenia
- Napisać style komunikatów sukcesu i błędów
- Napisać style panelu HR
- Napisać style panelu administratora
- Napisać style widoku publicznego
- Napisać style responsywne dla urządzeń mobilnych

## 18. JavaScript / interakcje frontendowe

- Dodać potwierdzenie usunięcia wersji roboczej
- Dodać potwierdzenie zamknięcia zgłoszenia
- Dodać dynamiczne pokazywanie nazw wybranych załączników
- Dodać prostą walidację pól po stronie przeglądarki
- Dodać obsługę rozwijanych sekcji, jeśli występują
- Dodać obsługę menu mobilnego
- Dodać automatyczne ukrywanie komunikatów flash
- Dodać blokadę podwójnego wysłania formularza

## 20. Porządkowanie kodu

- Uporządkować nazwy widoków
- Wydzielić powtarzalne fragmenty Blade do komponentów
