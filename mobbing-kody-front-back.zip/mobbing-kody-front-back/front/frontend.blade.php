<!--
Frontend code catalog.
This single file groups Blade, CSS and JavaScript snippets from the Laravel demo.
It is not meant to be run as one Blade template.
-->

<!-- ==================== resources/views/admin/audit/index.blade.php ==================== -->
@extends('layouts.app')

@section('title', 'Logi audytu')

@section('content')
<div class="card">
    <div class="actions" style="justify-content: space-between;">
        <h1>Logi audytu</h1>
        <div class="actions">
            <a class="button" href="{{ route('admin.users.index') }}">Użytkownicy</a>
            <a class="button" href="{{ route('admin.categories.index') }}">Kategorie</a>
        </div>
    </div>
    <p class="help">Metadane nie zawierają treści zgłoszeń, notatek ani ścieżek plików.</p>

    <form method="get" class="form-grid" action="{{ route('admin.audit.index') }}">
        <div class="form-row">
            <label for="action">Filtr akcji</label>
            <input type="text" name="action" id="action" value="{{ request('action') }}" placeholder="np. login, report">
        </div>
        <div class="form-row">
            <label>&nbsp;</label>
            <button class="button primary" type="submit">Filtruj</button>
        </div>
    </form>
</div>

<div class="card" style="margin-top: 18px;">
    <div class="table-responsive">
        <table>
            <thead>
            <tr>
                <th>Data</th>
                <th>Użytkownik</th>
                <th>Akcja</th>
                <th>Hash IP</th>
                <th>Metadane</th>
            </tr>
            </thead>
            <tbody>
            @forelse($logs as $log)
                <tr>
                    <td>{{ $log->created_at?->format('Y-m-d H:i:s') }}</td>
                    <td>{{ $log->user?->login ?? 'public/anonim' }}</td>
                    <td>{{ $log->action }}</td>
                    <td class="monospace">{{ $log->ip_hash ? substr($log->ip_hash, 0, 14) . '…' : 'brak' }}</td>
                    <td><pre class="monospace">{{ json_encode($log->metadata, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) }}</pre></td>
                </tr>
            @empty
                <tr><td colspan="5">Brak logów.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>

    <div class="pagination">
        <span>Strona {{ $logs->currentPage() }} z {{ $logs->lastPage() }}</span>
        <div class="actions">
            @if($logs->previousPageUrl())
                <a class="button" href="{{ $logs->previousPageUrl() }}">Poprzednia</a>
            @endif
            @if($logs->nextPageUrl())
                <a class="button" href="{{ $logs->nextPageUrl() }}">Następna</a>
            @endif
        </div>
    </div>
</div>
@endsection

<!-- ==================== resources/views/admin/categories/form.blade.php ==================== -->
@extends('layouts.app')

@section('title', $mode === 'create' ? 'Nowa kategoria' : 'Edycja kategorii')

@section('content')
<div class="card" style="max-width: 760px; margin: 0 auto;">
    <h1>{{ $mode === 'create' ? 'Nowa kategoria' : 'Edycja kategorii' }}</h1>

    <form method="post" action="{{ $mode === 'create' ? route('admin.categories.store') : route('admin.categories.update', $category) }}" class="grid">
        @csrf
        @if($mode === 'edit')
            @method('PUT')
        @endif

        <div class="form-row">
            <label for="category_name">Nazwa</label>
            <input type="text" name="category_name" id="category_name" value="{{ old('category_name', $category->category_name) }}" required>
        </div>

        <div class="form-row">
            <label for="description">Opis</label>
            <textarea name="description" id="description">{{ old('description', $category->description) }}</textarea>
        </div>

        <label class="help"><input type="checkbox" name="is_active" value="1" @checked(old('is_active', $category->is_active))> Widoczna w formularzu publicznym</label>

        <div class="actions">
            <button class="button primary" type="submit">Zapisz</button>
            <a class="button" href="{{ route('admin.categories.index') }}">Anuluj</a>
        </div>
    </form>
</div>
@endsection

<!-- ==================== resources/views/admin/categories/index.blade.php ==================== -->
@extends('layouts.app')

@section('title', 'Kategorie mobbingu')

@section('content')
<div class="card">
    <div class="actions" style="justify-content: space-between;">
        <h1>Słownik kategorii mobbingu</h1>
        <div class="actions">
            <a class="button" href="{{ route('admin.users.index') }}">Użytkownicy</a>
            <a class="button" href="{{ route('admin.audit.index') }}">Logi audytu</a>
            <a class="button primary" href="{{ route('admin.categories.create') }}">Nowa kategoria</a>
        </div>
    </div>

    <div class="table-responsive">
        <table>
            <thead>
            <tr>
                <th>Nazwa</th>
                <th>Opis</th>
                <th>Status</th>
                <th>Akcja</th>
            </tr>
            </thead>
            <tbody>
            @foreach($categories as $category)
                <tr>
                    <td>{{ $category->category_name }}</td>
                    <td>{{ $category->description }}</td>
                    <td>{{ $category->is_active ? 'Aktywna' : 'Ukryta' }}</td>
                    <td><a class="button" href="{{ route('admin.categories.edit', $category) }}">Edytuj</a></td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection

<!-- ==================== resources/views/admin/users/form.blade.php ==================== -->
@extends('layouts.app')

@section('title', $mode === 'create' ? 'Nowe konto' : 'Edycja konta')

@section('content')
<div class="card" style="max-width: 720px; margin: 0 auto;">
    <h1>{{ $mode === 'create' ? 'Nowe konto' : 'Edycja konta' }}</h1>

    <form method="post" action="{{ $mode === 'create' ? route('admin.users.store') : route('admin.users.update', $user) }}" class="grid">
        @csrf
        @if($mode === 'edit')
            @method('PUT')
        @endif

        <div class="form-row">
            <label for="login">Login</label>
            <input type="text" name="login" id="login" value="{{ old('login', $user->login) }}" required>
        </div>

        <div class="form-row">
            <label for="password">Hasło {{ $mode === 'edit' ? '(zostaw puste, aby nie zmieniać)' : '' }}</label>
            <input type="password" name="password" id="password" @required($mode === 'create')>
        </div>

        <div class="form-row">
            <label for="role">Rola</label>
            <select name="role" id="role" required>
                <option value="hr" @selected(old('role', $user->role) === 'hr')>Pracownik HR</option>
                <option value="admin" @selected(old('role', $user->role) === 'admin')>Administrator IT</option>
            </select>
        </div>

        <label class="help"><input type="checkbox" name="is_active" value="1" @checked(old('is_active', $user->is_active))> Konto aktywne</label>

        <div class="actions">
            <button class="button primary" type="submit">Zapisz</button>
            <a class="button" href="{{ route('admin.users.index') }}">Anuluj</a>
        </div>
    </form>
</div>
@endsection

<!-- ==================== resources/views/admin/users/index.blade.php ==================== -->
@extends('layouts.app')

@section('title', 'Administrator - użytkownicy')

@section('content')
<div class="card">
    <div class="actions" style="justify-content: space-between;">
        <h1>Kontami HR i administratorów</h1>
        <div class="actions">
            <a class="button" href="{{ route('admin.categories.index') }}">Kategorie</a>
            <a class="button" href="{{ route('admin.audit.index') }}">Logi audytu</a>
            <a class="button primary" href="{{ route('admin.users.create') }}">Nowe konto</a>
        </div>
    </div>
    <p class="help">Administrator IT zarządza kontami i słownikami, ale nie ma w panelu dostępu do treści zgłoszeń.</p>

    <div class="table-responsive">
        <table>
            <thead>
            <tr>
                <th>Login</th>
                <th>Rola</th>
                <th>Status</th>
                <th>Ostatnie logowanie</th>
                <th>Akcja</th>
            </tr>
            </thead>
            <tbody>
            @foreach($users as $user)
                <tr>
                    <td>{{ $user->login }}</td>
                    <td>{{ $user->roleLabel() }}</td>
                    <td>{{ $user->is_active ? 'Aktywne' : 'Zablokowane' }}</td>
                    <td>{{ $user->last_login_at?->format('Y-m-d H:i') ?? 'Brak' }}</td>
                    <td><a class="button" href="{{ route('admin.users.edit', $user) }}">Edytuj</a></td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection

<!-- ==================== resources/views/auth/login.blade.php ==================== -->
@extends('layouts.app')

@section('title', 'Logowanie - ' . config('app.name'))

@section('content')
<div class="card" style="max-width: 560px; margin: 0 auto;">
    <h1>Logowanie do panelu</h1>
    <p class="lead">Dostęp dla pracowników HR i administratora IT.</p>

    <form method="post" action="{{ route('login.post') }}" class="grid">
        @csrf
        <div class="form-row">
            <label for="login">Login</label>
            <input type="text" name="login" id="login" value="{{ old('login') }}" required autofocus>
        </div>
        <div class="form-row">
            <label for="password">Hasło</label>
            <input type="password" name="password" id="password" required>
        </div>
        <button class="button primary full" type="submit">Zaloguj</button>
    </form>

    <p class="help" style="margin-top: 18px;">Konta testowe: admin/admin123! oraz hr/hr123!</p>
</div>
@endsection

<!-- ==================== resources/views/hr/reports/index.blade.php ==================== -->
@extends('layouts.app')

@section('title', 'Panel HR - zgłoszenia')

@section('content')
<div class="card">
    <h1>Panel HR - zgłoszenia</h1>

    <form method="get" action="{{ route('hr.reports.index') }}" class="form-grid">
        <div class="form-row">
            <label for="status">Status</label>
            <select name="status" id="status">
                <option value="">Wszystkie</option>
                @foreach($statuses as $value => $label)
                    <option value="{{ $value }}" @selected(request('status') === $value)>{{ $label }}</option>
                @endforeach
            </select>
        </div>
        <div class="form-row">
            <label for="sort">Sortowanie</label>
            <select name="sort" id="sort">
                <option value="newest" @selected(request('sort', 'newest') === 'newest')>Od najnowszych</option>
                <option value="oldest" @selected(request('sort') === 'oldest')>Od najstarszych</option>
            </select>
        </div>
        <div class="form-row">
            <label>&nbsp;</label>
            <label class="help"><input type="checkbox" name="unread" value="1" @checked(request()->boolean('unread'))> Tylko nieprzeczytane</label>
        </div>
        <div class="form-row">
            <label>&nbsp;</label>
            <button class="button primary" type="submit">Filtruj</button>
        </div>
    </form>
</div>

<div class="card" style="margin-top: 18px;">
    <div class="table-responsive">
        <table>
            <thead>
            <tr>
                <th>ID</th>
                <th>Status</th>
                <th>Kategoria</th>
                <th>Data</th>
                <th>Załączniki</th>
                <th>Odczyt</th>
                <th>Akcja</th>
            </tr>
            </thead>
            <tbody>
            @forelse($reports as $report)
                <tr>
                    <td>#{{ $report->report_id }}</td>
                    <td><span class="badge {{ $report->status }}">{{ $report->statusLabel() }}</span></td>
                    <td>{{ $report->category?->category_name ?? 'Brak' }}</td>
                    <td>{{ $report->created_at?->format('Y-m-d H:i') }}</td>
                    <td>{{ $report->attachments_count }}</td>
                    <td>{{ $report->read_at ? 'Tak' : 'Nie' }}</td>
                    <td><a class="button" href="{{ route('hr.reports.show', $report) }}">Otwórz</a></td>
                </tr>
            @empty
                <tr><td colspan="7">Brak zgłoszeń dla wybranych filtrów.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>

    <div class="pagination">
        <span>Strona {{ $reports->currentPage() }} z {{ $reports->lastPage() }}</span>
        <div class="actions">
            @if($reports->previousPageUrl())
                <a class="button" href="{{ $reports->previousPageUrl() }}">Poprzednia</a>
            @endif
            @if($reports->nextPageUrl())
                <a class="button" href="{{ $reports->nextPageUrl() }}">Następna</a>
            @endif
        </div>
    </div>
</div>
@endsection

<!-- ==================== resources/views/hr/reports/show.blade.php ==================== -->
@extends('layouts.app')

@section('title', 'Zgłoszenie #' . $report->report_id)

@section('content')
<div class="card">
    <div class="actions" style="justify-content: space-between;">
        <h1>Zgłoszenie #{{ $report->report_id }}</h1>
        <a class="button" href="{{ route('hr.reports.index') }}">Wróć do listy</a>
    </div>

    @if($report->isClosed())
        <div class="notice info">Zgłoszenie ma status zakończone i jest tylko do odczytu.</div>
    @endif

    <dl class="kv">
        <dt>Status</dt>
        <dd><span class="badge {{ $report->status }}">{{ $report->statusLabel() }}</span></dd>
        <dt>Kategoria</dt>
        <dd>{{ $report->category?->category_name ?? 'Nie podano' }}</dd>
        <dt>Data wysłania</dt>
        <dd>{{ $report->created_at?->format('Y-m-d H:i') }}</dd>
        <dt>Data zdarzenia</dt>
        <dd>{{ $report->incident_date?->format('Y-m-d') ?? 'Nie podano' }}</dd>
        <dt>Działanie ciągłe</dt>
        <dd>{{ $report->is_continuous ? 'Tak' : 'Nie' }}</dd>
        <dt>Miejsce</dt>
        <dd>{{ $report->place ?: 'Nie podano' }}</dd>
        <dt>Częstotliwość</dt>
        <dd>{{ $report->frequency ?: 'Nie podano' }}</dd>
        <dt>Rola zgłaszającego</dt>
        <dd>{{ $report->reporterRoleLabel() }}</dd>
        <dt>Obsługujący HR</dt>
        <dd>{{ $report->hrUser?->login ?? 'Jeszcze nie przypisano' }}</dd>
    </dl>
</div>

<div class="grid two" style="margin-top: 18px;">
    <section class="card">
        <h2>Treść zgłoszenia</h2>
        <h3>Opis</h3>
        <p>{!! nl2br(e($report->description)) !!}</p>
        <h3>Osoba wskazana</h3>
        <p>{!! nl2br(e($report->accused_person ?: 'Nie podano')) !!}</p>
        <h3>Świadkowie</h3>
        <p>{!! nl2br(e($report->witnesses ?: 'Nie podano')) !!}</p>
        <h3>Wcześniejsze działania</h3>
        <p>{!! nl2br(e($report->previous_actions ?: 'Nie podano')) !!}</p>
    </section>

    <section class="card">
        <h2>Obsługa HR</h2>
        <form method="post" action="{{ route('hr.reports.status', $report) }}" class="grid">
            @csrf
            <div class="form-row">
                <label for="status">Status</label>
                <select name="status" id="status" @disabled($report->isClosed())>
                    @foreach($statuses as $value => $label)
                        <option value="{{ $value }}" @selected($report->status === $value)>{{ $label }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-row">
                <label for="feedback_hr">Komunikat widoczny dla zgłaszającego</label>
                <textarea name="feedback_hr" id="feedback_hr" @disabled($report->isClosed())>{{ old('feedback_hr', $report->feedback_hr) }}</textarea>
            </div>
            <button class="button primary" type="submit" @disabled($report->isClosed())>Zapisz status</button>
        </form>
    </section>
</div>

<div class="grid two" style="margin-top: 18px;">
    <section class="card">
        <h2>Załączniki</h2>
        @forelse($report->attachments as $attachment)
            <p>
                <a class="button" href="{{ route('hr.reports.attachments.download', [$report, $attachment]) }}">Pobierz</a>
                {{ $attachment->file_name }}
                <span class="help">({{ number_format(($attachment->size_bytes ?? 0) / 1024, 1, ',', ' ') }} KB)</span>
            </p>
        @empty
            <p class="help">Brak załączników.</p>
        @endforelse
    </section>

    <section class="card">
        <h2>Notatki wewnętrzne HR</h2>
        @forelse($report->notes as $note)
            <article class="notice info" style="margin-bottom: 12px;">
                <strong>{{ $note->user?->login ?? 'HR' }}</strong>, {{ $note->created_at?->format('Y-m-d H:i') }}<br>
                {!! nl2br(e($note->note)) !!}
            </article>
        @empty
            <p class="help">Nie dodano jeszcze notatek.</p>
        @endforelse

        <form method="post" action="{{ route('hr.reports.notes', $report) }}" class="grid">
            @csrf
            <div class="form-row">
                <label for="note">Nowa notatka</label>
                <textarea name="note" id="note" @disabled($report->isClosed())></textarea>
            </div>
            <button class="button primary" type="submit" @disabled($report->isClosed())>Dodaj notatkę</button>
        </form>
    </section>
</div>
@endsection

<!-- ==================== resources/views/layouts/app.blade.php ==================== -->
<!doctype html>
<html lang="pl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', config('app.name'))</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>
<body>
<header class="site-header">
    <div class="container header-inner">
        <a class="brand" href="{{ route('home') }}">
            <span>Anonimowe zgłaszanie mobbingu</span>
            <small>bezpieczny formularz i panel HR</small>
        </a>
        <nav class="nav" aria-label="Nawigacja główna">
            <a href="{{ route('public.reports.create') }}">Złóż zgłoszenie</a>
            <a href="{{ route('public.status.lookup') }}">Sprawdź status</a>
            @if($currentUser)
                @if($currentUser->role === 'hr')
                    <a href="{{ route('hr.reports.index') }}">Panel HR</a>
                @elseif($currentUser->role === 'admin')
                    <a href="{{ route('admin.users.index') }}">Panel admina</a>
                @endif
                <form method="post" action="{{ route('logout') }}" class="logout-form">
                    @csrf
                    <button type="submit">Wyloguj {{ $currentUser->login }}</button>
                </form>
            @else
                <a href="{{ route('login') }}">Panel HR/admin</a>
            @endif
        </nav>
    </div>
</header>

<main class="main">
    <div class="container">
        @if(session('success'))
            <div class="notice success">{{ session('success') }}</div>
        @endif
        @if(session('error'))
            <div class="notice danger">{{ session('error') }}</div>
        @endif
        @if($errors->any())
            <div class="notice danger">
                <strong>Popraw błędy w formularzu:</strong>
                <ul class="errors">
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        @yield('content')
    </div>
</main>

<button type="button" class="panic-button" data-panic-button title="Szybko opuść stronę">Panic button</button>

<footer class="footer">
    <div class="container">
        Lokalna wersja demonstracyjna. Nie podawaj danych osobowych, jeżeli nie jest to konieczne do opisania sprawy.
    </div>
</footer>

<script src="{{ asset('js/app.js') }}"></script>
@stack('scripts')
</body>
</html>

<!-- ==================== resources/views/public/create.blade.php ==================== -->
@extends('layouts.app')

@section('title', 'Nowe zgłoszenie - ' . config('app.name'))

@section('content')
<div class="card">
    <h1>Złóż anonimowe zgłoszenie</h1>
    <p class="lead">Wypełnij formularz możliwie rzeczowo. Pola z gwiazdką są wymagane.</p>

    <div class="notice">
        <strong>Ważne:</strong> system nie wymaga danych osobowych, ale opis sytuacji może pośrednio zdradzić tożsamość.
        Przed wysłaniem sprawdź, czy nie podajesz informacji, które nie są konieczne.
    </div>

    <form method="post" action="{{ route('public.reports.store') }}" enctype="multipart/form-data" class="form-grid" data-draft-form data-draft-key="anonymous-report-draft">
        @csrf

        <div class="form-row">
            <label for="category_id">Kategoria mobbingu</label>
            <select name="category_id" id="category_id">
                <option value="">Nie wybieram / nie wiem</option>
                @foreach($categories as $category)
                    <option value="{{ $category->category_id }}" @selected(old('category_id') == $category->category_id)>{{ $category->category_name }}</option>
                @endforeach
            </select>
        </div>

        <div class="form-row">
            <label for="reporter_role">Rola zgłaszającego</label>
            <select name="reporter_role" id="reporter_role">
                <option value="">Nie chcę podawać</option>
                @foreach($reporterRoles as $value => $label)
                    <option value="{{ $value }}" @selected(old('reporter_role') === $value)>{{ $label }}</option>
                @endforeach
            </select>
        </div>

        <div class="form-row full">
            <label for="description">Opis zdarzenia *</label>
            <textarea name="description" id="description" required placeholder="Opisz konkretne zachowania, słowa lub sytuacje. Wskaż fakty, a nie oceny.">{{ old('description') }}</textarea>
            <span class="help">Minimum 20 znaków. Unikaj danych osobowych, jeżeli nie są potrzebne do wyjaśnienia sprawy.</span>
        </div>

        <div class="form-row">
            <label for="incident_date">Kiedy miało miejsce zdarzenie?</label>
            <input type="date" name="incident_date" id="incident_date" value="{{ old('incident_date') }}">
        </div>

        <div class="form-row">
            <label for="is_continuous">Charakter zdarzenia</label>
            <label class="help"><input type="checkbox" name="is_continuous" id="is_continuous" value="1" @checked(old('is_continuous'))> To działanie ciągłe lub powtarzające się</label>
        </div>

        <div class="form-row">
            <label for="place">Gdzie dochodzi do sytuacji?</label>
            <input type="text" name="place" id="place" value="{{ old('place') }}" placeholder="np. biuro, dział, spotkanie online, komunikator">
        </div>

        <div class="form-row">
            <label for="frequency">Jak często?</label>
            <input type="text" name="frequency" id="frequency" value="{{ old('frequency') }}" placeholder="np. jednorazowo, kilka razy w miesiącu, codziennie">
        </div>

        <div class="form-row full">
            <label for="accused_person">Kto dopuszcza się niepożądanych zachowań?</label>
            <textarea name="accused_person" id="accused_person" placeholder="Możesz wpisać imię i nazwisko albo stanowisko/dział, jeżeli obawiasz się identyfikacji.">{{ old('accused_person') }}</textarea>
        </div>

        <div class="form-row full">
            <label for="witnesses">Czy ktoś był obecny lub wie o sprawie?</label>
            <textarea name="witnesses" id="witnesses" placeholder="Wpisz tylko informacje, które są potrzebne do rozpatrzenia sprawy.">{{ old('witnesses') }}</textarea>
        </div>

        <div class="form-row full">
            <label for="previous_actions">Czy próbowano już rozwiązać sprawę?</label>
            <textarea name="previous_actions" id="previous_actions" placeholder="Np. rozmowa z przełożonym, próba mediacji, wcześniejsze nieformalne zgłoszenie.">{{ old('previous_actions') }}</textarea>
        </div>

        <div class="form-row full">
            <label for="attachments">Załączniki</label>
            <input type="file" name="attachments[]" id="attachments" multiple>
            <span class="help">Możesz dodać screeny, maile, dokumenty lub nagrania. Pojedynczy plik maks. 20 MB.</span>
        </div>

        <div class="form-row full notice info">
            <label>
                <input type="checkbox" name="truth_confirmed" value="1" required @checked(old('truth_confirmed'))>
                Potwierdzam, że podane informacje są zgodne z moją wiedzą i przekonaniem. *
            </label>
        </div>

        <div class="form-row full">
            <div class="actions">
                <button type="submit" class="button primary">Wyślij zgłoszenie</button>
                <button type="button" class="button secondary" data-save-draft>Zapisz wersję roboczą na tym urządzeniu</button>
                <button type="button" class="button danger" data-delete-draft>Usuń wersję roboczą z tego urządzenia</button>
            </div>
            <p class="help" data-draft-message></p>
        </div>
    </form>
</div>
@endsection

<!-- ==================== resources/views/public/home.blade.php ==================== -->
@extends('layouts.app')

@section('title', 'Strona główna - ' . config('app.name'))

@section('content')
<section class="hero">
    <div class="card">
        <h1>Bezpieczne i anonimowe zgłaszanie mobbingu</h1>
        <p class="lead">
            System pozwala pracownikowi przekazać zgłoszenie bez zakładania konta, a działowi HR uporządkować obsługę spraw.
            Po wysłaniu zgłoszenia otrzymasz token/link oraz PIN do sprawdzania statusu.
        </p>
        <div class="actions">
            <a class="button primary" href="{{ route('public.reports.create') }}">Złóż anonimowe zgłoszenie</a>
            <a class="button" href="{{ route('public.status.lookup') }}">Sprawdź status zgłoszenia</a>
        </div>
    </div>
    <div class="card">
        <h2>Jak postępować?</h2>
        <ol class="lead">
            <li>Opisz fakty: zachowania, słowa, daty, miejsca i częstotliwość.</li>
            <li>Nie dodawaj danych, które nie są potrzebne do rozpatrzenia sprawy.</li>
            <li>Dołącz pliki tylko wtedy, gdy realnie pomagają wyjaśnić sytuację.</li>
            <li>Zapisz token i PIN. Bez nich nie da się wrócić do zgłoszenia.</li>
        </ol>
    </div>
</section>

<section class="grid three">
    <article class="card compact">
        <h3>Anonimowość</h3>
        <p class="help">Formularz nie wymaga konta ani danych osobowych. Pamiętaj jednak, że sam opis sytuacji może zdradzić tożsamość, np. przy spotkaniu 1 na 1.</p>
    </article>
    <article class="card compact">
        <h3>Wersja robocza</h3>
        <p class="help">W formularzu możesz zapisać wersję roboczą lokalnie w przeglądarce i usunąć ją jednym przyciskiem z urządzenia.</p>
    </article>
    <article class="card compact">
        <h3>Panic button</h3>
        <p class="help">Stały przycisk w prawym dolnym rogu szybko przekierowuje na neutralną stronę, gdy musisz natychmiast opuścić system.</p>
    </article>
</section>
@endsection

<!-- ==================== resources/views/public/status_lookup.blade.php ==================== -->
@extends('layouts.app')

@section('title', 'Sprawdź status - ' . config('app.name'))

@section('content')
<div class="card">
    <h1>Sprawdź status zgłoszenia</h1>
    <p class="lead">Wpisz token oraz PIN otrzymane po wysłaniu zgłoszenia.</p>

    <form method="post" action="{{ route('public.status.lookup.post') }}" class="form-grid">
        @csrf
        <div class="form-row">
            <label for="token">Token</label>
            <input type="text" name="token" id="token" value="{{ old('token') }}" required>
        </div>
        <div class="form-row">
            <label for="pin">PIN</label>
            <input type="password" name="pin" id="pin" required>
        </div>
        <div class="form-row full">
            <button class="button primary" type="submit">Pokaż status</button>
        </div>
    </form>
</div>
@endsection

<!-- ==================== resources/views/public/status_show.blade.php ==================== -->
@extends('layouts.app')

@section('title', 'Status zgłoszenia - ' . config('app.name'))

@section('content')
<div class="card">
    <h1>Status zgłoszenia</h1>
    <dl class="kv">
        <dt>Numer zgłoszenia</dt>
        <dd>#{{ $report->report_id }}</dd>

        <dt>Status</dt>
        <dd><span class="badge {{ $report->status }}">{{ $report->statusLabel() }}</span></dd>

        <dt>Kategoria</dt>
        <dd>{{ $report->category?->category_name ?? 'Nie podano' }}</dd>

        <dt>Data wysłania</dt>
        <dd>{{ $report->created_at?->format('Y-m-d H:i') }}</dd>

        <dt>Ostatnia aktualizacja</dt>
        <dd>{{ $report->updated_at?->format('Y-m-d H:i') }}</dd>
    </dl>

    <div class="card compact" style="margin-top: 18px;">
        <h2>Informacja od HR</h2>
        @if($report->feedback_hr)
            <p>{!! nl2br(e($report->feedback_hr)) !!}</p>
        @else
            <p class="help">HR nie dodał jeszcze komunikatu widocznego dla zgłaszającego.</p>
        @endif
    </div>
</div>
@endsection

<!-- ==================== resources/views/public/status_token.blade.php ==================== -->
@extends('layouts.app')

@section('title', 'PIN do zgłoszenia - ' . config('app.name'))

@section('content')
<div class="card">
    <h1>Podaj PIN do zgłoszenia</h1>
    <p class="lead">Token z linku: <span class="monospace">{{ $token }}</span></p>

    <form method="post" action="{{ route('public.status.token.post', $token) }}" class="form-grid">
        @csrf
        <div class="form-row">
            <label for="pin">PIN</label>
            <input type="password" name="pin" id="pin" required autofocus>
        </div>
        <div class="form-row full">
            <button class="button primary" type="submit">Pokaż status</button>
        </div>
    </form>
</div>
@endsection

<!-- ==================== resources/views/public/submitted.blade.php ==================== -->
@extends('layouts.app')

@section('title', 'Zgłoszenie wysłane - ' . config('app.name'))

@section('content')
<div class="card">
    <h1>Zgłoszenie zostało wysłane</h1>
    <div class="notice success">
        Zapisz poniższy link/token oraz PIN. Ze względu na anonimowość system nie ma procedury odzyskiwania PIN-u.
    </div>

    <div class="token-box" style="margin-top: 18px;">
        <div class="card compact">
            <h2>Token</h2>
            <p class="monospace">{{ $report->public_token }}</p>
        </div>
        <div class="card compact">
            <h2>PIN</h2>
            <p class="monospace">{{ $pin }}</p>
        </div>
    </div>

    <div class="card compact" style="margin-top: 18px;">
        <h2>Link do sprawy</h2>
        <p class="monospace">{{ $statusUrl }}</p>
        <a class="button primary" href="{{ $statusUrl }}">Przejdź do sprawdzania statusu</a>
    </div>
</div>
@endsection

{<!-- ==================== public/css/app.css ==================== -->}
<style>
:root {
    --bg: #f4f7fb;
    --surface: #ffffff;
    --surface-muted: #eef5fb;
    --text: #192333;
    --muted: #657386;
    --primary: #246899;
    --primary-dark: #174867;
    --danger: #b42318;
    --success: #157347;
    --warning: #9a6700;
    --border: #d7e2ec;
    --shadow: 0 16px 40px rgba(25, 35, 51, 0.08);
    --radius: 18px;
}

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    color: var(--text);
    background: linear-gradient(180deg, #f8fbff 0%, var(--bg) 35%, #eef4fa 100%);
    min-height: 100vh;
}

a {
    color: var(--primary);
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}

img {
    max-width: 100%;
}

.container {
    width: min(1120px, calc(100% - 32px));
    margin: 0 auto;
}

.site-header {
    position: sticky;
    top: 0;
    z-index: 50;
    background: rgba(255, 255, 255, 0.94);
    backdrop-filter: blur(12px);
    border-bottom: 1px solid var(--border);
}

.header-inner {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 18px;
    padding: 14px 0;
}

.brand {
    display: flex;
    flex-direction: column;
    gap: 2px;
    font-weight: 800;
    color: var(--text);
}

.brand small {
    color: var(--muted);
    font-weight: 500;
}

.nav {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 10px;
    justify-content: flex-end;
}

.nav a,
.nav button,
.button,
button.button {
    border: 0;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    min-height: 40px;
    padding: 10px 14px;
    border-radius: 999px;
    background: var(--surface-muted);
    color: var(--primary-dark);
    font-weight: 700;
    cursor: pointer;
    text-decoration: none;
    font-size: 0.95rem;
}

.nav a:hover,
.nav button:hover,
.button:hover {
    background: #dcecf8;
    text-decoration: none;
}

.button.primary {
    background: var(--primary);
    color: white;
}

.button.primary:hover {
    background: var(--primary-dark);
}

.button.danger {
    background: #ffe6e3;
    color: var(--danger);
}

.button.secondary {
    background: #eef2f7;
    color: var(--text);
}

.button.full {
    width: 100%;
}

.logout-form {
    display: inline;
}

.main {
    padding: 34px 0 56px;
}

.hero {
    display: grid;
    grid-template-columns: 1.25fr 0.75fr;
    gap: 24px;
    align-items: stretch;
    margin-bottom: 24px;
}

.card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    box-shadow: var(--shadow);
    padding: 24px;
}

.card.compact {
    padding: 18px;
}

.card h1,
.card h2,
.card h3 {
    margin-top: 0;
}

.hero h1 {
    font-size: clamp(2rem, 5vw, 4rem);
    line-height: 1.03;
    margin: 0 0 16px;
}

.lead {
    color: var(--muted);
    font-size: 1.08rem;
    line-height: 1.65;
}

.grid {
    display: grid;
    gap: 18px;
}

.grid.two {
    grid-template-columns: repeat(2, minmax(0, 1fr));
}

.grid.three {
    grid-template-columns: repeat(3, minmax(0, 1fr));
}

.form-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 18px;
}

.form-row {
    display: flex;
    flex-direction: column;
    gap: 7px;
}

.form-row.full {
    grid-column: 1 / -1;
}

label {
    font-weight: 750;
}

input,
select,
textarea {
    width: 100%;
    border: 1px solid var(--border);
    border-radius: 14px;
    padding: 12px 13px;
    font: inherit;
    background: #fff;
    color: var(--text);
}

textarea {
    min-height: 150px;
    resize: vertical;
}

input:focus,
select:focus,
textarea:focus {
    outline: 3px solid rgba(36, 104, 153, 0.18);
    border-color: var(--primary);
}

.help {
    color: var(--muted);
    font-size: 0.92rem;
    line-height: 1.5;
}

.notice {
    border-radius: 16px;
    padding: 14px 16px;
    background: #fff7e0;
    border: 1px solid #f0d890;
    color: #6b4b00;
    line-height: 1.55;
}

.notice.info {
    background: #eaf4ff;
    border-color: #bfdbfe;
    color: #174867;
}

.notice.success {
    background: #e7f8ef;
    border-color: #b7e6cb;
    color: #135a39;
}

.notice.danger {
    background: #ffeceb;
    border-color: #ffc9c4;
    color: var(--danger);
}

.errors {
    padding-left: 18px;
    margin: 8px 0 0;
}

.badge {
    display: inline-flex;
    border-radius: 999px;
    padding: 5px 10px;
    font-size: 0.82rem;
    font-weight: 800;
    background: #eef2f7;
    color: var(--text);
    white-space: nowrap;
}

.badge.submitted {
    background: #eaf4ff;
    color: #1d4e89;
}

.badge.in_review {
    background: #fff7e0;
    color: #805600;
}

.badge.closed {
    background: #e7f8ef;
    color: #135a39;
}

.table-responsive {
    overflow-x: auto;
    border-radius: 16px;
    border: 1px solid var(--border);
}

table {
    width: 100%;
    border-collapse: collapse;
    min-width: 720px;
    background: white;
}

th,
td {
    text-align: left;
    padding: 12px 14px;
    border-bottom: 1px solid var(--border);
    vertical-align: top;
}

th {
    background: #f3f7fb;
    color: #304055;
    font-size: 0.9rem;
}

tr:last-child td {
    border-bottom: 0;
}

.kv {
    display: grid;
    grid-template-columns: 220px 1fr;
    gap: 10px 18px;
}

.kv dt {
    color: var(--muted);
    font-weight: 750;
}

.kv dd {
    margin: 0;
}

.token-box {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 14px;
}

.monospace {
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", monospace;
    word-break: break-word;
}

.panic-button {
    position: fixed;
    right: 18px;
    bottom: 18px;
    z-index: 100;
    background: var(--danger);
    color: #fff;
    border: 0;
    border-radius: 999px;
    padding: 13px 18px;
    box-shadow: 0 18px 36px rgba(180, 35, 24, 0.26);
    cursor: pointer;
    font-weight: 900;
}

.panic-button:hover {
    filter: brightness(0.92);
}

.actions {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    align-items: center;
}

.footer {
    padding: 22px 0 42px;
    color: var(--muted);
    text-align: center;
}

.pagination {
    display: flex;
    justify-content: space-between;
    gap: 12px;
    align-items: center;
    margin-top: 18px;
}

@media (max-width: 820px) {
    .container {
        width: min(100% - 22px, 1120px);
    }

    .header-inner,
    .hero,
    .grid.two,
    .grid.three,
    .form-grid,
    .token-box {
        grid-template-columns: 1fr;
    }

    .header-inner {
        display: grid;
        align-items: start;
    }

    .nav {
        justify-content: flex-start;
    }

    .card {
        padding: 18px;
    }

    .kv {
        grid-template-columns: 1fr;
    }

    .panic-button {
        right: 12px;
        bottom: 12px;
        padding: 12px 14px;
        font-size: 0.92rem;
    }
}

@media (max-width: 520px) {
    .nav a,
    .nav button,
    .button,
    button.button {
        width: 100%;
    }

    .actions {
        flex-direction: column;
        align-items: stretch;
    }

    table {
        min-width: 620px;
    }
}
</style>

{<!-- ==================== public/js/app.js ==================== -->}
<script>
(function () {
    const panicTarget = 'https://www.gov.pl/';

    window.panicExit = function () {
        try {
            window.location.replace(panicTarget);
        } catch (error) {
            window.location.href = panicTarget;
        }
    };

    function draftKey(form) {
        return form.getAttribute('data-draft-key') || 'anonymous-report-draft';
    }

    function serializeDraft(form) {
        const data = {};
        const fields = form.querySelectorAll('input, textarea, select');

        fields.forEach((field) => {
            if (!field.name || field.type === 'file' || field.name === '_token') {
                return;
            }

            if (field.type === 'checkbox') {
                data[field.name] = field.checked;
                return;
            }

            data[field.name] = field.value;
        });

        return data;
    }

    function restoreDraft(form) {
        const raw = window.localStorage.getItem(draftKey(form));
        if (!raw) {
            return;
        }

        try {
            const data = JSON.parse(raw);
            Object.keys(data).forEach((name) => {
                const field = form.querySelector(`[name="${CSS.escape(name)}"]`);
                if (!field) {
                    return;
                }

                if (field.type === 'checkbox') {
                    field.checked = Boolean(data[name]);
                } else {
                    field.value = data[name];
                }
            });
        } catch (error) {
            window.localStorage.removeItem(draftKey(form));
        }
    }

    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('[data-panic-button]').forEach((button) => {
            button.addEventListener('click', window.panicExit);
        });

        const form = document.querySelector('[data-draft-form]');
        if (!form) {
            return;
        }

        restoreDraft(form);

        const saveButton = document.querySelector('[data-save-draft]');
        const deleteButton = document.querySelector('[data-delete-draft]');
        const draftMessage = document.querySelector('[data-draft-message]');

        if (saveButton) {
            saveButton.addEventListener('click', function () {
                window.localStorage.setItem(draftKey(form), JSON.stringify(serializeDraft(form)));
                if (draftMessage) {
                    draftMessage.textContent = 'Wersja robocza została zapisana lokalnie w tej przeglądarce.';
                }
            });
        }

        if (deleteButton) {
            deleteButton.addEventListener('click', function () {
                window.localStorage.removeItem(draftKey(form));
                if (draftMessage) {
                    draftMessage.textContent = 'Wersja robocza została usunięta z tego urządzenia.';
                }
            });
        }

        form.addEventListener('submit', function () {
            window.localStorage.removeItem(draftKey(form));
        });
    });
})();
</script>
