# Podział kodu według `kody.md`

Struktura ma charakter katalogu kodów/snippetów. Nie jest gotowym projektem do uruchomienia.

## Front

- `front/frontend.blade.php` – jeden zbiorczy plik z widokami Blade, CSS i JS, podzielony komentarzami na sekcje.
- `front/README.md` – lista tasków frontendowych obsługiwanych przez ten plik.

## Back

### 1. Struktura aplikacji i routing

- `back/01-1-struktura-aplikacji-i-routing/01-utworzyc-routing-dla-czesci-publicznej-aplikacji.php` – Utworzyć routing dla części publicznej aplikacji
- `back/01-1-struktura-aplikacji-i-routing/02-utworzyc-routing-dla-panelu-hr.php` – Utworzyć routing dla panelu HR
- `back/01-1-struktura-aplikacji-i-routing/03-utworzyc-routing-dla-panelu-administratora.php` – Utworzyć routing dla panelu administratora
- `back/01-1-struktura-aplikacji-i-routing/04-utworzyc-routing-dla-obslugi-logowania.php` – Utworzyć routing dla obsługi logowania
- `back/01-1-struktura-aplikacji-i-routing/05-utworzyc-routing-dla-obslugi-zgloszen-po-tokenie.php` – Utworzyć routing dla obsługi zgłoszeń po tokenie
- `back/01-1-struktura-aplikacji-i-routing/06-utworzyc-routing-dla-pobierania-zalacznikow.php` – Utworzyć routing dla pobierania załączników
- `back/01-1-struktura-aplikacji-i-routing/07-utworzyc-routing-dla-akcji-zmiany-statusow-zgloszen.php` – Utworzyć routing dla akcji zmiany statusów zgłoszeń
- `back/01-1-struktura-aplikacji-i-routing/08-utworzyc-routing-dla-wiadomosci-w-zgloszeniu.php` – Utworzyć routing dla wiadomości w zgłoszeniu

### 2. Część publiczna – zgłaszający

- `back/02-2-czesc-publiczna-zglaszajacy/04-dodac-walidacje-formularza-zgloszenia-po-stronie-backendu.php` – Dodać walidację formularza zgłoszenia po stronie backendu
- `back/02-2-czesc-publiczna-zglaszajacy/06-stworzyc-obsluge-zapisu-zgloszenia-jako-wersji-roboczej.php` – Stworzyć obsługę zapisu zgłoszenia jako wersji roboczej
- `back/02-2-czesc-publiczna-zglaszajacy/07-stworzyc-obsluge-wyslania-zgloszenia.php` – Stworzyć obsługę wysłania zgłoszenia
- `back/02-2-czesc-publiczna-zglaszajacy/08-stworzyc-generowanie-i-wyswietlanie-tokenu-zgloszenia.php` – Stworzyć generowanie i wyświetlanie tokenu zgłoszenia
- `back/02-2-czesc-publiczna-zglaszajacy/12-stworzyc-tryb-read-only-dla-zgloszenia-zamknietego.php` – Stworzyć tryb read-only dla zgłoszenia zamkniętego
- `back/02-2-czesc-publiczna-zglaszajacy/13-stworzyc-obsluge-usuwania-wersji-roboczej.php` – Stworzyć obsługę usuwania wersji roboczej

### 3. Załączniki

- `back/03-3-zalaczniki/02-dodac-backendowa-obsluge-uploadu-zalacznikow.php` – Dodać backendową obsługę uploadu załączników
- `back/03-3-zalaczniki/03-dodac-walidacje-typu-pliku.php` – Dodać walidację typu pliku
- `back/03-3-zalaczniki/04-dodac-walidacje-rozmiaru-pliku.php` – Dodać walidację rozmiaru pliku
- `back/03-3-zalaczniki/05-dodac-liste-zalacznikow-przy-zgloszeniu.php` – Dodać listę załączników przy zgłoszeniu
- `back/03-3-zalaczniki/06-dodac-mozliwosc-usuniecia-zalacznika-z-wersji-roboczej.php` – Dodać możliwość usunięcia załącznika z wersji roboczej
- `back/03-3-zalaczniki/07-dodac-bezpieczne-pobieranie-zalacznikow-przez-hr.php` – Dodać bezpieczne pobieranie załączników przez HR
- `back/03-3-zalaczniki/08-dodac-bezpieczne-pobieranie-zalacznikow-przez-zglaszajacego-po-tokenie.php` – Dodać bezpieczne pobieranie załączników przez zgłaszającego po tokenie
- `back/03-3-zalaczniki/09-zabezpieczyc-dostep-do-zalacznikow-przed-nieuprawnionym-pobraniem.php` – Zabezpieczyć dostęp do załączników przed nieuprawnionym pobraniem

### 4. Komunikacja zgłaszający – HR

- `back/04-4-komunikacja-zglaszajacy-hr/05-dodac-rozroznienie-autora-wiadomosci.php` – Dodać rozróżnienie autora wiadomości
- `back/04-4-komunikacja-zglaszajacy-hr/06-dodac-sortowanie-wiadomosci-chronologicznie.php` – Dodać sortowanie wiadomości chronologicznie
- `back/04-4-komunikacja-zglaszajacy-hr/07-dodac-blokade-dodawania-wiadomosci-po-zamknieciu-zgloszenia.php` – Dodać blokadę dodawania wiadomości po zamknięciu zgłoszenia
- `back/04-4-komunikacja-zglaszajacy-hr/09-dodac-komunikaty-o-braku-wiadomosci.php` – Dodać komunikaty o braku wiadomości

### 5. Panel HR

- `back/05-5-panel-hr/01-stworzyc-dashboard-hr.php` – Stworzyć dashboard HR
- `back/05-5-panel-hr/02-stworzyc-liste-zgloszen-dla-hr.php` – Stworzyć listę zgłoszeń dla HR
- `back/05-5-panel-hr/03-dodac-filtrowanie-zgloszen-po-statusie.php` – Dodać filtrowanie zgłoszeń po statusie
- `back/05-5-panel-hr/04-dodac-wyszukiwanie-zgloszen.php` – Dodać wyszukiwanie zgłoszeń
- `back/05-5-panel-hr/05-dodac-sortowanie-zgloszen.php` – Dodać sortowanie zgłoszeń
- `back/05-5-panel-hr/07-dodac-zmiane-statusu-zgloszenia.php` – Dodać zmianę statusu zgłoszenia
- `back/05-5-panel-hr/08-dodac-przypisywanie-zgloszenia-do-uzytkownika-hr.php` – Dodać przypisywanie zgłoszenia do użytkownika HR
- `back/05-5-panel-hr/09-dodac-obsluge-notatek-wewnetrznych-hr.php` – Dodać obsługę notatek wewnętrznych HR
- `back/05-5-panel-hr/10-dodac-widocznosc-zalacznikow-w-szczegolach-zgloszenia.php` – Dodać widoczność załączników w szczegółach zgłoszenia
- `back/05-5-panel-hr/11-dodac-widocznosc-historii-wiadomosci.php` – Dodać widoczność historii wiadomości
- `back/05-5-panel-hr/12-dodac-akcje-zamkniecia-zgloszenia.php` – Dodać akcję zamknięcia zgłoszenia
- `back/05-5-panel-hr/13-dodac-blokade-edycji-zamknietego-zgloszenia.php` – Dodać blokadę edycji zamkniętego zgłoszenia

### 6. Panel administratora

- `back/06-6-panel-administratora/01-stworzyc-dashboard-administratora.php` – Stworzyć dashboard administratora
- `back/06-6-panel-administratora/02-stworzyc-liste-uzytkownikow.php` – Stworzyć listę użytkowników
- `back/06-6-panel-administratora/05-dodac-zmiane-roli-uzytkownika.php` – Dodać zmianę roli użytkownika
- `back/06-6-panel-administratora/06-dodac-aktywowanie-i-dezaktywowanie-uzytkownikow.php` – Dodać aktywowanie i dezaktywowanie użytkowników
- `back/06-6-panel-administratora/07-dodac-resetowanie-hasla-uzytkownika.php` – Dodać resetowanie hasła użytkownika
- `back/06-6-panel-administratora/09-dodac-liste-zgloszen-dostepna-dla-administratora.php` – Dodać listę zgłoszeń dostępną dla administratora
- `back/06-6-panel-administratora/10-dodac-podglad-szczegolow-zgloszenia-dla-administratora.php` – Dodać podgląd szczegółów zgłoszenia dla administratora
- `back/06-6-panel-administratora/11-dodac-widok-audytu-systemowego.php` – Dodać widok audytu systemowego
- `back/06-6-panel-administratora/12-dodac-filtrowanie-wpisow-audytu.php` – Dodać filtrowanie wpisów audytu
- `back/06-6-panel-administratora/13-dodac-komunikaty-akcji-administracyjnych.php` – Dodać komunikaty akcji administracyjnych

### 7. Logowanie i autoryzacja

- `back/07-7-logowanie-i-autoryzacja/01-stworzyc-widok-logowania-uzytkownika-wewnetrznego.php` – Stworzyć widok logowania użytkownika wewnętrznego
- `back/07-7-logowanie-i-autoryzacja/02-stworzyc-backendowa-obsluge-logowania.php` – Stworzyć backendową obsługę logowania
- `back/07-7-logowanie-i-autoryzacja/03-stworzyc-backendowa-obsluge-wylogowania.php` – Stworzyć backendową obsługę wylogowania
- `back/07-7-logowanie-i-autoryzacja/04-dodac-middleware-zabezpieczajacy-panel-hr.php` – Dodać middleware zabezpieczający panel HR
- `back/07-7-logowanie-i-autoryzacja/05-dodac-middleware-zabezpieczajacy-panel-administratora.php` – Dodać middleware zabezpieczający panel administratora
- `back/07-7-logowanie-i-autoryzacja/06-dodac-sprawdzanie-rol-uzytkownikow.php` – Dodać sprawdzanie ról użytkowników
- `back/07-7-logowanie-i-autoryzacja/07-dodac-przekierowania-po-zalogowaniu-zaleznie-od-roli.php` – Dodać przekierowania po zalogowaniu zależnie od roli
- `back/07-7-logowanie-i-autoryzacja/08-dodac-obsluge-blednych-danych-logowania.php` – Dodać obsługę błędnych danych logowania
- `back/07-7-logowanie-i-autoryzacja/10-dodac-zabezpieczenie-akcji-backendowych-przed-nieuprawnionym-uzyciem.php` – Dodać zabezpieczenie akcji backendowych przed nieuprawnionym użyciem

### 8. Statusy i logika zgłoszeń

- `back/08-8-statusy-i-logika-zgloszen/01-zaimplementowac-logike-tworzenia-nowego-zgloszenia.php` – Zaimplementować logikę tworzenia nowego zgłoszenia
- `back/08-8-statusy-i-logika-zgloszen/02-zaimplementowac-logike-wersji-roboczej.php` – Zaimplementować logikę wersji roboczej
- `back/08-8-statusy-i-logika-zgloszen/03-zaimplementowac-logike-wyslania-zgloszenia.php` – Zaimplementować logikę wysłania zgłoszenia
- `back/08-8-statusy-i-logika-zgloszen/04-zaimplementowac-logike-zmiany-statusu-zgloszenia.php` – Zaimplementować logikę zmiany statusu zgłoszenia
- `back/08-8-statusy-i-logika-zgloszen/05-zaimplementowac-logike-zamkniecia-zgloszenia.php` – Zaimplementować logikę zamknięcia zgłoszenia
- `back/08-8-statusy-i-logika-zgloszen/06-zaimplementowac-logike-blokady-zamknietego-zgloszenia.php` – Zaimplementować logikę blokady zamkniętego zgłoszenia
- `back/08-8-statusy-i-logika-zgloszen/07-zaimplementowac-logike-dostepu-do-zgloszenia-po-tokenie.php` – Zaimplementować logikę dostępu do zgłoszenia po tokenie
- `back/08-8-statusy-i-logika-zgloszen/08-zaimplementowac-logike-ukrywania-danych-technicznych-przed-zglaszajacym.php` – Zaimplementować logikę ukrywania danych technicznych przed zgłaszającym
- `back/08-8-statusy-i-logika-zgloszen/09-zaimplementowac-logike-walidacji-dozwolonych-przejsc-miedzy-statusami.php` – Zaimplementować logikę walidacji dozwolonych przejść między statusami

### 9. Audyt i logowanie zdarzeń

- `back/09-9-audyt-i-logowanie-zdarzen/01-dodac-zapisywanie-zdarzenia-utworzenia-zgloszenia.php` – Dodać zapisywanie zdarzenia utworzenia zgłoszenia
- `back/09-9-audyt-i-logowanie-zdarzen/02-dodac-zapisywanie-zdarzenia-wyslania-zgloszenia.php` – Dodać zapisywanie zdarzenia wysłania zgłoszenia
- `back/09-9-audyt-i-logowanie-zdarzen/03-dodac-zapisywanie-zdarzenia-zmiany-statusu.php` – Dodać zapisywanie zdarzenia zmiany statusu
- `back/09-9-audyt-i-logowanie-zdarzen/04-dodac-zapisywanie-zdarzenia-dodania-wiadomosci.php` – Dodać zapisywanie zdarzenia dodania wiadomości
- `back/09-9-audyt-i-logowanie-zdarzen/05-dodac-zapisywanie-zdarzenia-dodania-zalacznika.php` – Dodać zapisywanie zdarzenia dodania załącznika
- `back/09-9-audyt-i-logowanie-zdarzen/06-dodac-zapisywanie-zdarzenia-pobrania-zalacznika.php` – Dodać zapisywanie zdarzenia pobrania załącznika
- `back/09-9-audyt-i-logowanie-zdarzen/07-dodac-zapisywanie-zdarzenia-logowania-uzytkownika.php` – Dodać zapisywanie zdarzenia logowania użytkownika
- `back/09-9-audyt-i-logowanie-zdarzen/08-dodac-zapisywanie-zdarzenia-operacji-administracyjnych.php` – Dodać zapisywanie zdarzenia operacji administracyjnych
- `back/09-9-audyt-i-logowanie-zdarzen/09-stworzyc-helper-serwis-do-zapisywania-audytu.php` – Stworzyć helper / serwis do zapisywania audytu
- `back/09-9-audyt-i-logowanie-zdarzen/10-stworzyc-widok-listy-wpisow-audytu.php` – Stworzyć widok listy wpisów audytu
- `back/09-9-audyt-i-logowanie-zdarzen/11-dodac-filtrowanie-audytu-po-typie-zdarzenia.php` – Dodać filtrowanie audytu po typie zdarzenia
- `back/09-9-audyt-i-logowanie-zdarzen/12-dodac-filtrowanie-audytu-po-uzytkowniku.php` – Dodać filtrowanie audytu po użytkowniku
- `back/09-9-audyt-i-logowanie-zdarzen/13-dodac-filtrowanie-audytu-po-zgloszeniu.php` – Dodać filtrowanie audytu po zgłoszeniu

### 10. Retencja i automatyczne czyszczenie

- `back/10-10-retencja-i-automatyczne-czyszczenie/01-zaimplementowac-logike-wykrywania-starych-wersji-roboczych.php` – Zaimplementować logikę wykrywania starych wersji roboczych
- `back/10-10-retencja-i-automatyczne-czyszczenie/02-zaimplementowac-usuwanie-przeterminowanych-wersji-roboczych.php` – Zaimplementować usuwanie przeterminowanych wersji roboczych
- `back/10-10-retencja-i-automatyczne-czyszczenie/03-zaimplementowac-czyszczenie-powiazanych-wiadomosci-roboczych.php` – Zaimplementować czyszczenie powiązanych wiadomości roboczych
- `back/10-10-retencja-i-automatyczne-czyszczenie/04-zaimplementowac-czyszczenie-powiazanych-zalacznikow-roboczych.php` – Zaimplementować czyszczenie powiązanych załączników roboczych
- `back/10-10-retencja-i-automatyczne-czyszczenie/05-dodac-kod-komendy-aplikacyjnej-do-czyszczenia-danych.php` – Dodać kod komendy aplikacyjnej do czyszczenia danych
- `back/10-10-retencja-i-automatyczne-czyszczenie/06-dodac-komunikaty-wynik-wykonania-komendy-retencyjnej.php` – Dodać komunikaty / wynik wykonania komendy retencyjnej
- `back/10-10-retencja-i-automatyczne-czyszczenie/07-dodac-wpisy-audytu-dla-operacji-retencyjnych.php` – Dodać wpisy audytu dla operacji retencyjnych

### 13. Walidacja i obsługa błędów

- `back/13-13-walidacja-i-obsluga-bledow/01-dodac-walidacje-tworzenia-zgloszenia.php` – Dodać walidację tworzenia zgłoszenia
- `back/13-13-walidacja-i-obsluga-bledow/02-dodac-walidacje-edycji-wersji-roboczej.php` – Dodać walidację edycji wersji roboczej
- `back/13-13-walidacja-i-obsluga-bledow/03-dodac-walidacje-dodawania-wiadomosci.php` – Dodać walidację dodawania wiadomości
- `back/13-13-walidacja-i-obsluga-bledow/04-dodac-walidacje-uploadu-zalacznikow.php` – Dodać walidację uploadu załączników
- `back/13-13-walidacja-i-obsluga-bledow/05-dodac-walidacje-zmiany-statusu.php` – Dodać walidację zmiany statusu
- `back/13-13-walidacja-i-obsluga-bledow/07-dodac-obsluge-blednego-tokenu.php` – Dodać obsługę błędnego tokenu
- `back/13-13-walidacja-i-obsluga-bledow/08-dodac-obsluge-wygaslego-usunietego-zgloszenia-roboczego.php` – Dodać obsługę wygasłego / usuniętego zgłoszenia roboczego
- `back/13-13-walidacja-i-obsluga-bledow/09-dodac-obsluge-braku-uprawnien.php` – Dodać obsługę braku uprawnień
- `back/13-13-walidacja-i-obsluga-bledow/10-dodac-obsluge-nieistniejacego-zasobu.php` – Dodać obsługę nieistniejącego zasobu
- `back/13-13-walidacja-i-obsluga-bledow/11-dodac-przyjazne-strony-bledow.php` – Dodać przyjazne strony błędów

### 14. Kontrolery backendowe

- `back/14-14-kontrolery-backendowe/01-napisac-kontroler-strony-publicznej.php` – Napisać kontroler strony publicznej
- `back/14-14-kontrolery-backendowe/02-napisac-kontroler-zgloszen-publicznych.php` – Napisać kontroler zgłoszeń publicznych
- `back/14-14-kontrolery-backendowe/03-napisac-kontroler-dostepu-po-tokenie.php` – Napisać kontroler dostępu po tokenie
- `back/14-14-kontrolery-backendowe/04-napisac-kontroler-zalacznikow.php` – Napisać kontroler załączników
- `back/14-14-kontrolery-backendowe/05-napisac-kontroler-wiadomosci.php` – Napisać kontroler wiadomości
- `back/14-14-kontrolery-backendowe/06-napisac-kontroler-panelu-hr.php` – Napisać kontroler panelu HR
- `back/14-14-kontrolery-backendowe/07-napisac-kontroler-zgloszen-hr.php` – Napisać kontroler zgłoszeń HR
- `back/14-14-kontrolery-backendowe/08-napisac-kontroler-panelu-administratora.php` – Napisać kontroler panelu administratora
- `back/14-14-kontrolery-backendowe/09-napisac-kontroler-uzytkownikow.php` – Napisać kontroler użytkowników
- `back/14-14-kontrolery-backendowe/10-napisac-kontroler-audytu.php` – Napisać kontroler audytu
- `back/14-14-kontrolery-backendowe/11-napisac-kontroler-logowania.php` – Napisać kontroler logowania
- `back/14-14-kontrolery-backendowe/12-napisac-kontroler-retencji-czyszczenia-danych.php` – Napisać kontroler retencji / czyszczenia danych

### 15. Serwisy i logika aplikacyjna

- `back/15-15-serwisy-i-logika-aplikacyjna/01-napisac-serwis-tworzenia-zgloszenia.php` – Napisać serwis tworzenia zgłoszenia
- `back/15-15-serwisy-i-logika-aplikacyjna/02-napisac-serwis-generowania-tokenu.php` – Napisać serwis generowania tokenu
- `back/15-15-serwisy-i-logika-aplikacyjna/03-napisac-serwis-obslugi-statusow-zgloszen.php` – Napisać serwis obsługi statusów zgłoszeń
- `back/15-15-serwisy-i-logika-aplikacyjna/04-napisac-serwis-obslugi-wiadomosci.php` – Napisać serwis obsługi wiadomości
- `back/15-15-serwisy-i-logika-aplikacyjna/05-napisac-serwis-obslugi-zalacznikow.php` – Napisać serwis obsługi załączników
- `back/15-15-serwisy-i-logika-aplikacyjna/06-napisac-serwis-audytu.php` – Napisać serwis audytu
- `back/15-15-serwisy-i-logika-aplikacyjna/07-napisac-serwis-retencji-danych.php` – Napisać serwis retencji danych
- `back/15-15-serwisy-i-logika-aplikacyjna/08-napisac-serwis-uprawnien-do-zgloszenia.php` – Napisać serwis uprawnień do zgłoszenia
- `back/15-15-serwisy-i-logika-aplikacyjna/09-napisac-serwis-operacji-administracyjnych-na-uzytkownikach.php` – Napisać serwis operacji administracyjnych na użytkownikach
- `back/15-15-serwisy-i-logika-aplikacyjna/10-napisac-helpery-formatowania-statusow-i-dat.php` – Napisać helpery formatowania statusów i dat

### 19. Testy kodu aplikacyjnego

- `back/19-19-testy-kodu-aplikacyjnego/01-napisac-test-tworzenia-zgloszenia.php` – Napisać test tworzenia zgłoszenia
- `back/19-19-testy-kodu-aplikacyjnego/02-napisac-test-zapisu-wersji-roboczej.php` – Napisać test zapisu wersji roboczej
- `back/19-19-testy-kodu-aplikacyjnego/03-napisac-test-wyslania-zgloszenia.php` – Napisać test wysłania zgłoszenia
- `back/19-19-testy-kodu-aplikacyjnego/04-napisac-test-dostepu-po-tokenie.php` – Napisać test dostępu po tokenie
- `back/19-19-testy-kodu-aplikacyjnego/05-napisac-test-blednego-tokenu.php` – Napisać test błędnego tokenu
- `back/19-19-testy-kodu-aplikacyjnego/06-napisac-test-dodawania-wiadomosci.php` – Napisać test dodawania wiadomości
- `back/19-19-testy-kodu-aplikacyjnego/07-napisac-test-dodawania-zalacznika.php` – Napisać test dodawania załącznika
- `back/19-19-testy-kodu-aplikacyjnego/08-napisac-test-pobierania-zalacznika.php` – Napisać test pobierania załącznika
- `back/19-19-testy-kodu-aplikacyjnego/09-napisac-test-zmiany-statusu-przez-hr.php` – Napisać test zmiany statusu przez HR
- `back/19-19-testy-kodu-aplikacyjnego/10-napisac-test-zamkniecia-zgloszenia.php` – Napisać test zamknięcia zgłoszenia
- `back/19-19-testy-kodu-aplikacyjnego/11-napisac-test-blokady-zamknietego-zgloszenia.php` – Napisać test blokady zamkniętego zgłoszenia
- `back/19-19-testy-kodu-aplikacyjnego/12-napisac-test-logowania-uzytkownika.php` – Napisać test logowania użytkownika
- `back/19-19-testy-kodu-aplikacyjnego/13-napisac-test-dostepu-do-panelu-hr.php` – Napisać test dostępu do panelu HR
- `back/19-19-testy-kodu-aplikacyjnego/14-napisac-test-dostepu-do-panelu-administratora.php` – Napisać test dostępu do panelu administratora
- `back/19-19-testy-kodu-aplikacyjnego/15-napisac-test-operacji-administracyjnych-na-uzytkownikach.php` – Napisać test operacji administracyjnych na użytkownikach
- `back/19-19-testy-kodu-aplikacyjnego/16-napisac-test-zapisu-audytu.php` – Napisać test zapisu audytu
- `back/19-19-testy-kodu-aplikacyjnego/17-napisac-test-retencji-wersji-roboczych.php` – Napisać test retencji wersji roboczych

### 20. Porządkowanie kodu

- `back/20-20-porzadkowanie-kodu/01-uporzadkowac-nazwy-kontrolerow.php` – Uporządkować nazwy kontrolerów
- `back/20-20-porzadkowanie-kodu/02-uporzadkowac-nazwy-serwisow.php` – Uporządkować nazwy serwisów
- `back/20-20-porzadkowanie-kodu/05-usunac-duplikaty-kodu-w-kontrolerach.php` – Usunąć duplikaty kodu w kontrolerach
- `back/20-20-porzadkowanie-kodu/06-przeniesc-logike-biznesowa-z-kontrolerow-do-serwisow.php` – Przenieść logikę biznesową z kontrolerów do serwisów
- `back/20-20-porzadkowanie-kodu/07-ujednolicic-komunikaty-bledow.php` – Ujednolicić komunikaty błędów
- `back/20-20-porzadkowanie-kodu/08-ujednolicic-komunikaty-sukcesu.php` – Ujednolicić komunikaty sukcesu
- `back/20-20-porzadkowanie-kodu/09-ujednolicic-formatowanie-dat.php` – Ujednolicić formatowanie dat
- `back/20-20-porzadkowanie-kodu/10-ujednolicic-nazwy-statusow.php` – Ujednolicić nazwy statusów
- `back/20-20-porzadkowanie-kodu/11-sprawdzic-obsluge-pustych-stanow.php` – Sprawdzić obsługę pustych stanów
- `back/20-20-porzadkowanie-kodu/12-sprawdzic-obsluge-wyjatkow.php` – Sprawdzić obsługę wyjątków

